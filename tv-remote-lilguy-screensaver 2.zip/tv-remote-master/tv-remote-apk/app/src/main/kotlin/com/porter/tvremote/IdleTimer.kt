package com.porter.tvremote

import android.os.SystemClock

/**
 * Tracks when the server was last used, so RemoteService can shut itself down after a day of
 * nothing. Every web request, macro run and minute of screensaver counts as use, so while you
 * are using the TV it never expires and you never have to restart it by hand.
 */
internal class IdleTimer(private val clock: () -> Long = { SystemClock.elapsedRealtime() }) {
    @Volatile private var lastUse = clock()

    fun touch() { lastUse = clock() }

    fun idleMs(): Long = clock() - lastUse

    fun isExpired(timeoutMs: Long): Boolean = idleMs() >= timeoutMs

    companion object {
        const val DEFAULT_TIMEOUT_MS = 24L * 60 * 60 * 1000

        /** The one timer the whole app shares. */
        val shared = IdleTimer()
    }
}
