package com.porter.tvremote

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import java.time.Instant
import java.util.Random

/** One piece of loot. Slots are weapon / armor / item; rarities common..legendary. */
internal data class GearPiece(val slot: String, val rarity: String, val bonus: Int)

/**
 * Read-only view of a lilguy save, as returned by lilguy-notifier's `/api/load-save`.
 * Nothing here ever writes back: you can look at him, but you can't feed him from the TV.
 */
internal data class LilguySnapshot(
    val mood: Int,                    // 1 happy, 2 neutral, 3 angry
    val hunger: Double,               // 0..20 as last saved; use [hungerAt] for "now"
    val lastHungerCheckMs: Long?,
    val hp: Int,
    val maxHp: Int,
    val level: Int,
    val dmg: Int,
    val bond: Double,
    val gear: List<GearPiece>,
    val unlockedTiers: Set<Int>,      // bond thresholds, e.g. 500 = "wink" tier
    val sleepWakeAtMs: Long?,
    val username: String?,
) {
    /** Same rule the game uses on load: asleep while the wake-up time is still ahead. */
    fun isSleeping(nowMs: Long): Boolean = sleepWakeAtMs != null && nowMs < sleepWakeAtMs

    /** Saved hunger minus one point per hour since the last check, like startup.js does. */
    fun hungerAt(nowMs: Long): Double {
        val since = lastHungerCheckMs ?: return hunger.coerceIn(0.0, MAX_HUNGER)
        val hours = ((nowMs - since) / 3_600_000.0).coerceAtLeast(0.0)
        return (hunger - hours).coerceIn(0.0, MAX_HUNGER)
    }

    fun gearIn(slot: String): GearPiece? = gear.firstOrNull { it.slot == slot }

    fun bondLabel(): String = when {
        bond >= 100 * BOND_SCALE -> "inseparable"
        bond >= 60 * BOND_SCALE -> "close"
        bond >= 30 * BOND_SCALE -> "comfortable"
        bond >= 10 * BOND_SCALE -> "getting to know each other"
        else -> "just met"
    }

    companion object {
        const val MAX_HUNGER = 20.0
        const val BOND_SCALE = 50

        private val json = Json { ignoreUnknownKeys = true }

        /** Parses the `/api/load-save` response body: `{ "save": {...}, "saveCode": "..." }`. */
        fun parseResponse(body: String): LilguySnapshot {
            val root = json.parseToJsonElement(body).jsonObject
            val save = (root["save"] as? JsonObject) ?: error("Response has no save")
            return fromSave(save)
        }

        fun fromSave(save: JsonObject): LilguySnapshot = LilguySnapshot(
            mood = save.int("mood", 2).coerceIn(1, 3),
            hunger = save.double("hunger", MAX_HUNGER),
            lastHungerCheckMs = (save["last_hunger_check"] as? JsonPrimitive)?.contentOrNull()?.let(::parseInstantMs),
            hp = save.int("hp", 5),
            maxHp = save.int("max_hp", 5).coerceAtLeast(1),
            level = save.int("level", 0),
            dmg = save.int("dmg", 1),
            bond = save.double("bond", 0.0),
            gear = parseGear(save["gear"]),
            unlockedTiers = parseTiers(save["unlocked_tiers"]),
            sleepWakeAtMs = save.double("sleep_wake_at", Double.NaN).takeIf { !it.isNaN() && it > 0 }?.toLong(),
            username = (save["username"] as? JsonPrimitive)?.contentOrNull()?.takeIf { it.isNotBlank() },
        )

        private fun JsonPrimitive.contentOrNull(): String? = if (isString) content else null

        private fun JsonObject.double(key: String, default: Double): Double =
            (this[key] as? JsonPrimitive)?.doubleOrNull ?: default

        private fun JsonObject.int(key: String, default: Int): Int = double(key, default.toDouble()).toInt()

        private fun parseInstantMs(text: String): Long? =
            runCatching { Instant.parse(text).toEpochMilli() }.getOrNull()

        /** Firebase returns arrays as JSON arrays, or as objects when entries are sparse. */
        private fun elements(el: JsonElement?): List<JsonElement> = when (el) {
            is JsonArray -> el.toList()
            is JsonObject -> el.values.toList()
            else -> emptyList()
        }

        private fun parseGear(el: JsonElement?): List<GearPiece> = elements(el).mapNotNull { item ->
            val o = item as? JsonObject ?: return@mapNotNull null
            val slot = (o["slot"] as? JsonPrimitive)?.contentOrNull() ?: return@mapNotNull null
            val rarity = (o["rarity"] as? JsonPrimitive)?.contentOrNull() ?: "common"
            GearPiece(slot, rarity, o.int("bonus", 0))
        }

        private fun parseTiers(el: JsonElement?): Set<Int> =
            elements(el).mapNotNull { (it as? JsonPrimitive)?.doubleOrNull?.toInt() }.toSet()
    }
}

/** The lines he says, copied from lilguy's state-data.js so the TV sounds like the game. */
internal object LilguySpeech {
    private val happy = listOf(
        "hehe :)", "today's a good day", "glad you're here",
        "i love you <3", "i like it when you're around",
        "thank you for spending time with me",
    )
    private val neutral = listOf(
        "...", "just vibing", "hm", "wassup.",
        "today felt normal. in a good way",
        "do you ever wonder why theres so much violence",
        "i've been thinking about that walk earlier",
        "do you ever wonder what's outside the window",
        "sometimes i just sit here and think",
        "someday...ill see others like me",
    )
    private val angry = listOf(">:(", "not now.", ">:{", "leave me alone.", "its lonely when you leave me")
    private val season = mapOf(
        "winter" to listOf("it's cold out there, huh", "i wish i could see snow", "let's stay inside today"),
        "spring" to listOf("everything is growing again", "i can smell the flowers. probably.", "spring always feels hopeful"),
        "summer" to listOf("it's so warm out", "summer's my favorite honestly", "i bet its bright outside right now"),
        "fall" to listOf("the leaves must be falling", "fall always feels a little nostalgic", "cozy season, right?"),
    )

    /** Bond thresholds (bond points) that unlock extra lines and a new face. */
    private val tiers = listOf(
        Tier(10 * LilguySnapshot.BOND_SCALE, "^_^", listOf("hehe, i feel closer to you now", "something feels different. good different.")),
        Tier(30 * LilguySnapshot.BOND_SCALE, "\\o/", listOf("i wanna dance!!", "watch this!")),
        Tier(60 * LilguySnapshot.BOND_SCALE, "<3_<3", listOf("you're my favorite person, you know that?", "i really mean it. thank you.")),
        Tier(100 * LilguySnapshot.BOND_SCALE, "[o]", listOf("we've really been through it together huh", "i wouldn't trade this for anything")),
    )

    private class Tier(val threshold: Int, val face: String, val lines: List<String>)

    fun seasonOf(month: Int): String = when (month) {
        12, 1, 2 -> "winter"
        3, 4, 5 -> "spring"
        6, 7, 8 -> "summer"
        else -> "fall"
    }

    /** Mirrors tick.js: a quarter of the time a seasonal line (never when angry), else a mood line. */
    fun pick(s: LilguySnapshot, month: Int, random: Random = Random()): String {
        if (random.nextInt(4) == 0 && s.mood != 3) return season.getValue(seasonOf(month)).random(random)
        val pool = when (s.mood) {
            1 -> happy + unlockedLines(s)
            2 -> neutral
            else -> angry
        }
        return pool.random(random)
    }

    /** Face for the screen: the highest unlocked tier's sprite, else a plain one for his mood. */
    fun face(s: LilguySnapshot): String {
        tiers.lastOrNull { it.threshold in s.unlockedTiers }?.let { return it.face }
        return when (s.mood) {
            1 -> "^_^"
            3 -> ">_<"
            else -> "o_o"
        }
    }

    private fun unlockedLines(s: LilguySnapshot): List<String> =
        tiers.filter { it.threshold in s.unlockedTiers }.flatMap { it.lines }

    private fun <T> List<T>.random(r: Random): T = this[r.nextInt(size)]
}
