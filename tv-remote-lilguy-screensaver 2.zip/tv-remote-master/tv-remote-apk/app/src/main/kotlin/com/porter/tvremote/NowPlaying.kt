package com.porter.tvremote

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import androidx.core.app.NotificationManagerCompat

/**
 * Exists only so Android lets this app read other apps' media sessions: that API requires an
 * enabled notification listener. It never looks at any notification.
 */
class NowPlayingListener : NotificationListenerService()

internal data class Track(val title: String, val artist: String)

internal object NowPlaying {
    private val LISTENER = "%s/%s"

    fun listenerComponent(context: Context): String =
        LISTENER.format(context.packageName, NowPlayingListener::class.java.name)

    fun hasAccess(context: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    /** The track that is playing right now, or null (nothing playing, or no access granted). */
    fun current(context: Context): Track? {
        if (!hasAccess(context)) return null
        return runCatching {
            val manager = context.getSystemService(MediaSessionManager::class.java)
            val sessions = manager.getActiveSessions(ComponentName(context, NowPlayingListener::class.java))
            val playing = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: return@runCatching null
            val meta = playing.metadata ?: return@runCatching null
            val title = meta.getString(MediaMetadata.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
                ?: return@runCatching null
            val artist = (meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty()
            Track(title, artist)
        }.getOrNull()
    }
}
