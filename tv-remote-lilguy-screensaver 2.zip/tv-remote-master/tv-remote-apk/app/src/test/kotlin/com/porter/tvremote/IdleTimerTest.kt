package com.porter.tvremote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IdleTimerTest {
    private var now = 1_000L
    private val timer = IdleTimer { now }

    @Test fun expiresOnlyAfterTheTimeoutWithoutUse() {
        now += IdleTimer.DEFAULT_TIMEOUT_MS - 1
        assertFalse(timer.isExpired(IdleTimer.DEFAULT_TIMEOUT_MS))
        now += 1
        assertTrue(timer.isExpired(IdleTimer.DEFAULT_TIMEOUT_MS))
    }

    @Test fun useRestartsTheDay() {
        now += 20 * 3_600_000L
        timer.touch()
        now += 20 * 3_600_000L
        assertEquals(20 * 3_600_000L, timer.idleMs())
        assertFalse(timer.isExpired(IdleTimer.DEFAULT_TIMEOUT_MS))
    }
}
