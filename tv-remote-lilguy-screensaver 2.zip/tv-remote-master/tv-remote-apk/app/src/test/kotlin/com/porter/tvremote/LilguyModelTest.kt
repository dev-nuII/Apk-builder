package com.porter.tvremote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class LilguyModelTest {
    private val body = """
        {"saveCode":"ABCD-EFGH-JKLM","dev":false,"save":{
          "mood":1,"hunger":18,"last_hunger_check":"2026-10-20T12:00:00.000Z",
          "hp":4,"max_hp":9,"level":3,"dmg":2,"bond":600,
          "gear":[{"slot":"armor","rarity":"rare","bonus":5},{"slot":"weapon","rarity":"common","bonus":1}],
          "unlocked_tiers":[500],"sleep_wake_at":null,"username":"Porter"}}
    """.trimIndent()

    @Test fun parsesSave() {
        val s = LilguySnapshot.parseResponse(body)
        assertEquals(1, s.mood)
        assertEquals(9, s.maxHp)
        assertEquals("Porter", s.username)
        assertEquals(5, s.gearIn("armor")?.bonus)
        assertNull(s.gearIn("item"))
        assertNull(s.sleepWakeAtMs)
        assertEquals("getting to know each other", s.bondLabel()) // 600 >= 10 * 50, < 30 * 50
    }

    @Test fun parsesGearAsObjectAndMissingFields() {
        val s = LilguySnapshot.parseResponse("""{"save":{"gear":{"1":{"slot":"item","rarity":"epic","bonus":9}}}}""")
        assertEquals("item", s.gear.single().slot)
        assertEquals(2, s.mood)
        assertEquals(5, s.maxHp)
    }

    @Test fun hungerDrainsOnePerHourAndClamps() {
        val s = LilguySnapshot.parseResponse(body)
        val start = java.time.Instant.parse("2026-10-20T12:00:00Z").toEpochMilli()
        assertEquals(18.0, s.hungerAt(start), 0.001)
        assertEquals(15.0, s.hungerAt(start + 3 * 3_600_000L), 0.001)
        assertEquals(0.0, s.hungerAt(start + 40 * 3_600_000L), 0.001)
        assertEquals(18.0, s.hungerAt(start - 5 * 3_600_000L), 0.001) // clock skew never raises it
    }

    @Test fun sleepingOnlyWhileWakeTimeIsAhead() {
        val s = LilguySnapshot.parseResponse("""{"save":{"sleep_wake_at":2000}}""")
        assertTrue(s.isSleeping(1999))
        assertFalse(s.isSleeping(2000))
        assertFalse(LilguySnapshot.parseResponse(body).isSleeping(1))
    }

    @Test fun codeValidation() {
        assertEquals("ABCD-EFGH-JKLM", LilguyApi.normalizeCode("  abcd-efgh-jklm "))
        assertTrue(LilguyApi.isValidCode("ABCD-EFGH-JKLM"))
        assertFalse(LilguyApi.isValidCode("ABCDEFGHJKLM"))
        assertFalse(LilguyApi.isValidCode("ABCD-EFGH-JKL"))
        assertFalse(LilguyApi.isValidCode("dev"))
    }

    @Test fun speechAndSeasons() {
        assertEquals("winter", LilguySpeech.seasonOf(12))
        assertEquals("fall", LilguySpeech.seasonOf(10))
        val s = LilguySnapshot.parseResponse(body)
        assertEquals("^_^", LilguySpeech.face(s))
        repeat(50) { assertNotNull(LilguySpeech.pick(s, 10, Random(it.toLong()))) }
        val angry = LilguySnapshot.parseResponse("""{"save":{"mood":3}}""")
        assertEquals(">_<", LilguySpeech.face(angry))
    }
}
