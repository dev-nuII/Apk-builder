package com.porter.tvremote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class LilguyModelTest {
    private val body = """
        {"saveCode":"ABCD-EFGH-JKLM","dev":false,"save":{
          "mood":1,"hunger":18,"last_hunger_check":"2026-10-20T12:00:00.000Z",
          "hp":4,"max_hp":9,"level":3,"dmg":2,"bond":600,
          "gear":[{"slot":"armor","rarity":"rare","bonus":5},{"slot":"weapon","rarity":"common","bonus":1}],
          "unlocked_tiers":[500],"sleep_wake_at":null,"username":"Porter"}}
    """.trimIndent()

    @Test fun parsesSave() {
        val s = LilguySnapshot.parseResponse(body)
        assertEquals(1, s.mood)
        assertEquals(9, s.maxHp)
        assertEquals("Porter", s.username)
        assertEquals(5, s.gearIn("armor")?.bonus)
        assertNull(s.gearIn("item"))
        assertNull(s.sleepWakeAtMs)
        assertEquals("getting to know each other", s.bondLabel()) // 600 >= 10 * 50, < 30 * 50
    }

    @Test fun parsesGearAsObjectAndMissingFields() {
        val s = LilguySnapshot.parseResponse("""{"save":{"gear":{"1":{"slot":"item","rarity":"epic","bonus":9}}}}""")
        assertEquals("item", s.gear.single().slot)
        assertEquals(2, s.mood)
        assertEquals(5, s.maxHp)
    }

    @Test fun hungerDrainsOnePerHourAndClamps() {
        val s = LilguySnapshot.parseResponse(body)
        val start = java.time.Instant.parse("2026-10-20T12:00:00Z").toEpochMilli()
        assertEquals(18.0, s.hungerAt(start), 0.001)
        assertEquals(15.0, s.hungerAt(start + 3 * 3_600_000L), 0.001)
        assertEquals(0.0, s.hungerAt(start + 40 * 3_600_000L), 0.001)
        assertEquals(18.0, s.hungerAt(start - 5 * 3_600_000L), 0.001) // clock skew never raises it
    }

    @Test fun sleepingOnlyWhileWakeTimeIsAhead() {
        val s = LilguySnapshot.parseResponse("""{"save":{"sleep_wake_at":2000}}""")
        assertTrue(s.isSleeping(1999))
        assertFalse(s.isSleeping(2000))
        assertFalse(LilguySnapshot.parseResponse(body).isSleeping(1))
    }

    @Test fun codeValidation() {
        assertEquals("ABCD-EFGH-JKLM", LilguyApi.normalizeCode("  abcd-efgh-jklm "))
        assertTrue(LilguyApi.isValidCode("ABCD-EFGH-JKLM"))
        assertFalse(LilguyApi.isValidCode("ABCDEFGHJKLM"))
        assertFalse(LilguyApi.isValidCode("ABCD-EFGH-JKL"))
        assertFalse(LilguyApi.isValidCode("dev"))
    }

    private val noon = java.time.Instant.parse("2026-10-20T12:00:00Z").toEpochMilli()

    private fun save(mood: Int = 1, hunger: Int = 20, hp: Int = 5, maxHp: Int = 5) = LilguySnapshot.parseResponse(
        """{"save":{"mood":$mood,"hunger":$hunger,"last_hunger_check":"2026-10-20T12:00:00.000Z","hp":$hp,"max_hp":$maxHp}}"""
    )

    @Test fun speechAndSeasons() {
        assertEquals("winter", LilguySpeech.seasonOf(12))
        assertEquals("fall", LilguySpeech.seasonOf(10))
        val s = LilguySnapshot.parseResponse(body)
        repeat(50) { assertNotNull(LilguySpeech.pick(s, 10, noon, Random(it.toLong()))) }
    }

    @Test fun lowBarsPullTheVibeDown() {
        assertEquals(Vibe(1, hungry = false, hurt = false), save().vibe(noon))
        assertEquals(2, save(hunger = 10).vibe(noon).mood)                     // 50% hunger: at best neutral
        assertEquals(2, save(hp = 3, maxHp = 5).vibe(noon).mood)               // 60% hp: at best neutral
        assertEquals(Vibe(3, hungry = true, hurt = false), save(hunger = 6).vibe(noon)) // 30%: upset, like the red bar
        assertEquals(Vibe(3, hungry = false, hurt = true), save(hp = 1, maxHp = 5).vibe(noon))
        assertEquals(3, save(mood = 3).vibe(noon).mood)                        // a bad day stays a bad day
        assertEquals(3, save(hunger = 20).vibe(noon + 15 * 3_600_000L).mood)   // and hunger keeps draining
    }

    @Test fun lowBarsNeverGetCheerfulLines() {
        val hungry = save(mood = 1, hunger = 2)
        val cheerful = setOf("hehe :)", "i love you <3", "today's a good day", "glad you're here")
        repeat(200) { assertFalse(LilguySpeech.pick(hungry, 10, noon, Random(it.toLong())) in cheerful) }
    }

    @Test fun facesFollowMoodAndWeights() {
        val rnd = Random(42) // one generator: Random(0), Random(1)... give correlated first values
        val happy = (0 until 4000).map { LilguyFace.pick(1, rnd) }.groupingBy { it }.eachCount()
        assertEquals(setOf("<_", "_>", "o7", "o/", "^_^", "O_O"), happy.keys)
        assertTrue(happy.getValue("<_") > happy.getValue("o7") * 1.5)
        assertTrue(happy.getValue("_>") > happy.getValue("O_O") * 1.5)
        val upset = (0 until 1000).map { LilguyFace.pick(3, rnd) }.toSet()
        assertEquals(setOf("<_", "_>", "o7", "O_O"), upset)
        assertTrue(LilguyFace.canShow("^_^", 1))
        assertFalse(LilguyFace.canShow("^_^", 2))
    }

    @Test fun lineWaitsThreeMinutesAndFaceFive() {
        val r = LilguyRotation(Random(1))
        val s = save()
        r.update(s, noon, 10)
        val line = r.line
        val face = r.face
        // Poll every 5 seconds for just under 3 minutes: nothing may change.
        var t = noon
        while (t < noon + LilguyRotation.LINE_INTERVAL_MS - 5_000) {
            t += 5_000
            r.update(s, t, 10)
            assertEquals(line, r.line)
            assertEquals(face, r.face)
        }
        // A line is re-picked at 3 minutes and again 3 minutes after that, never sooner.
        var changes = 0
        var last = r.line
        var lastChange = noon
        while (t < noon + 60 * 60_000L) {
            t += 5_000
            r.update(s, t, 10)
            if (r.line != last) { assertTrue(t - lastChange >= LilguyRotation.LINE_INTERVAL_MS); last = r.line; lastChange = t; changes++ }
        }
        assertTrue(changes > 5)
    }

    @Test fun facePicksAtMostOncePerSlot() {
        val r = LilguyRotation(Random(7))
        val s = save()
        r.update(s, noon, 10)
        var last = r.face
        var lastChange = noon
        var t = noon
        while (t < noon + 4 * 3_600_000L) {
            t += 5_000
            r.update(s, t, 10)
            if (r.face != last) { assertTrue(t - lastChange >= LilguyFace.SLOT_MS); last = r.face; lastChange = t }
        }
    }

    @Test fun vibeChangeRepicksAtOnceSoNothingContradictsTheBars() {
        val r = LilguyRotation(Random(3))
        r.update(save(mood = 1), noon, 10)
        // Thirty seconds later his hunger bar is low (new save): no waiting for the 3 minutes.
        val hungrySave = save(mood = 1, hunger = 2)
        r.update(hungrySave, noon + 30_000, 10)
        assertTrue(r.line in setOf("my tummy's rumbling", "is it snack time yet?", "i could really use something to eat", "so hungry..."))
        assertTrue(LilguyFace.canShow(r.face, 3))
    }

    @Test fun clockSetBackwardsDoesNotFreezeTheLine() {
        val r = LilguyRotation(Random(5))
        val s = save()
        r.update(s, noon, 10)
        r.update(s, noon - 3_600_000L, 10) // would otherwise wait an hour of "negative" time
        // Reaching here without exception is the point; the line was allowed to refresh.
        assertNotNull(r.line)
    }
}
