package com.porter.tvremote

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.service.dreams.DreamService
import android.text.format.DateFormat
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

/** Everything the screen shows, swapped in whole so drawing never sees a half-update. */
internal data class ScreenData(
    val lilguy: LilguySnapshot? = null,
    val lilguyError: String? = null,
    val weather: Weather? = null,
    val track: Track? = null,
    val line: String = "...",
    val face: String = "<_",
)

/**
 * Draws the screensaver. Two looks:
 *  - lilguy awake (or no save code set up): clock, weather, music, and his stats and speech
 *  - lilguy asleep: pure black with only the track, artist, date, time and weather
 *
 * Everything that moves is eased so it never jumps: the burn-in drift is a continuous curve, the
 * bars glide to new values, and his face and line cross-fade. The screen only redraws every
 * frame while one of those is actually moving; otherwise once a second.
 */
internal class LilguyScreenView(context: Context) : View(context) {
    @Volatile var data: ScreenData = ScreenData()
        set(value) { field = value; postInvalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG or Paint.LINEAR_TEXT_FLAG)
    private val mono = Typeface.MONOSPACE
    private val sans = Typeface.SANS_SERIF
    private val italic = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
    private val bar = RectF()

    private val is24 = DateFormat.is24HourFormat(context)
    private val timeFormat = SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault())
    private val ampmFormat = SimpleDateFormat("a", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())

    // Formatted once per second instead of on every frame.
    private var clockSecond = -1L
    private var timeText = ""
    private var dateText = ""

    // Animation state (only touched while drawing, on the UI thread).
    private var animating = false
    private var lastFrameMs = 0L
    private var shownFace = ""
    private var prevFace: String? = null
    private var faceChangedMs = 0L
    private var shownLine = ""
    private var prevLine: String? = null
    private var lineChangedMs = 0L
    private var hungerShown = -1f
    private var hpShown = -1f
    private val wrapCache = HashMap<String, List<String>>()

    init { setBackgroundColor(Color.BLACK) }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val d = data
        val now = System.currentTimeMillis()
        val frameDt = if (lastFrameMs == 0L) 0L else (now - lastFrameMs).coerceIn(0L, 100L)
        lastFrameMs = now
        animating = false
        updateClock(now)
        val sleeping = d.lilguy?.isSleeping(now) == true
        // Slow continuous drift so nothing sits on the same pixels for hours (TV burn-in).
        // Two sine waves with different periods trace a wandering path with no sudden jumps.
        val u = height / 1080f
        val t = now / 1000.0
        val dx = (sin(2 * PI * t / DRIFT_X_SECONDS) * 30 * u).toFloat()
        val dy = (sin(2 * PI * t / DRIFT_Y_SECONDS) * 18 * u).toFloat()
        canvas.save()
        canvas.translate(dx, dy)
        if (sleeping) drawSleeping(canvas, d, u) else drawAwake(canvas, d, u, now, frameDt)
        canvas.restore()
        if (animating) postInvalidateOnAnimation()
    }

    // ── Sleeping: black, grey text, nothing else ─────────────────────────────

    private fun drawSleeping(c: Canvas, d: ScreenData, u: Float) {
        val cx = width / 2f
        var y = height * 0.36f
        paint.color = GREY_BRIGHT
        text(c, timeText, cx, y, 230 * u, sans, Paint.Align.CENTER)
        y += 90 * u
        paint.color = GREY
        text(c, dateText, cx, y, 52 * u, sans, Paint.Align.CENTER)
        y += 76 * u
        paint.color = if (d.weather == null) GREY_DIM else GREY
        text(c, d.weather?.display() ?: "weather unavailable", cx, y, 46 * u, sans, Paint.Align.CENTER)
        y += 100 * u
        d.track?.let { drawTrack(c, it, cx, y, u, Paint.Align.CENTER) }
    }

    // ── Awake ────────────────────────────────────────────────────────────────

    private fun drawAwake(c: Canvas, d: ScreenData, u: Float, nowMs: Long, frameDt: Long) {
        val left = 90 * u
        var y = 230 * u
        paint.color = Color.WHITE
        text(c, timeText, left, y, 170 * u, sans, Paint.Align.LEFT)
        y += 70 * u
        paint.color = GREY_BRIGHT
        text(c, dateText, left, y, 46 * u, sans, Paint.Align.LEFT)
        y += 64 * u
        paint.color = if (d.weather == null) GREY_DIM else GREY_BRIGHT
        text(c, d.weather?.display() ?: "weather unavailable", left, y, 46 * u, sans, Paint.Align.LEFT)
        d.track?.let { drawTrack(c, it, left, height - 110 * u, u, Paint.Align.LEFT) }

        paint.color = ORANGE
        text(c, "made with Claude and lilguydev", width - 70 * u, height - 60 * u, 26 * u, sans, Paint.Align.RIGHT)

        val l = d.lilguy
        val col = width * 0.60f
        if (l == null) {
            paint.color = GREY
            val msg = d.lilguyError ?: "Add a lilguy save code in the web remote to see him here"
            text(c, msg, col, height * 0.45f, 34 * u, sans, Paint.Align.LEFT)
            return
        }

        // Face: cross-fades when it changes.
        if (d.face != shownFace) {
            prevFace = shownFace.ifEmpty { null }
            shownFace = d.face
            faceChangedMs = nowMs
        }
        val faceP = progress(nowMs, faceChangedMs)
        val oldFace = prevFace
        if (oldFace != null) {
            if (faceP < 1f) drawFace(c, oldFace, 1f - faceP, col, u) else prevFace = null
        }
        drawFace(c, shownFace, faceP, col, u)

        // Line: cross-fades when it changes.
        if (d.line != shownLine) {
            prevLine = shownLine.ifEmpty { null }
            shownLine = d.line
            lineChangedMs = nowMs
        }
        val lineP = progress(nowMs, lineChangedMs)
        val oldLine = prevLine
        if (oldLine != null) {
            if (lineP < 1f) drawSpeech(c, oldLine, 1f - lineP, col, u) else prevLine = null
        }
        drawSpeech(c, shownLine, lineP, col, u)

        // Bars glide toward their real value instead of jumping when a refresh brings new numbers.
        val hunger = l.hungerAt(nowMs)
        hungerShown = approach(hungerShown, (hunger / LilguySnapshot.MAX_HUNGER).toFloat(), frameDt)
        hpShown = approach(hpShown, l.hp.toFloat() / l.maxHp, frameDt)

        var row = 520 * u
        row = statBar(c, "HUNGER", hungerShown, "%.0f / 20".format(hunger), col, row, u,
            if (hunger < 6) Color.rgb(255, 90, 90) else Color.rgb(120, 220, 120))
        row = statBar(c, "HP", hpShown, "${l.hp} / ${l.maxHp}", col, row, u, Color.rgb(255, 120, 150))

        paint.color = GREY_BRIGHT
        text(c, "LV ${l.level}   DMG ${l.dmg}   ${l.bondLabel()}", col, row + 6 * u, 34 * u, sans, Paint.Align.LEFT)
        row += 52 * u
        text(c, "SLEEP  awake", col, row, 34 * u, sans, Paint.Align.LEFT)
        row += 64 * u

        for (slot in listOf("weapon", "armor", "item")) {
            val g = l.gearIn(slot)
            paint.color = if (g == null) GREY_DIM else rarityColor(g.rarity)
            val label = if (g == null) "—" else "${g.rarity} +${g.bonus}"
            text(c, slot.uppercase().padEnd(7) + label, col, row, 32 * u, mono, Paint.Align.LEFT)
            row += 46 * u
        }
    }

    private fun drawFace(c: Canvas, face: String, alpha: Float, col: Float, u: Float) {
        paint.color = withAlpha(Color.rgb(0, 255, 120), alpha)
        text(c, face, col + 170 * u, 250 * u, 150 * u, mono, Paint.Align.CENTER)
    }

    private fun drawSpeech(c: Canvas, line: String, alpha: Float, col: Float, u: Float) {
        paint.color = withAlpha(Color.rgb(255, 235, 210), alpha)
        var sy = 330 * u
        for (part in wrapped("\"$line\"")) {
            text(c, part, col + 170 * u, sy, 40 * u, italic, Paint.Align.CENTER)
            sy += 52 * u
        }
    }

    private fun statBar(c: Canvas, label: String, frac: Float, value: String, x: Float, y: Float, u: Float, color: Int): Float {
        paint.color = GREY
        text(c, label, x, y, 26 * u, sans, Paint.Align.LEFT)
        val top = y + 14 * u
        val w = width * 0.30f
        paint.color = Color.argb(60, 255, 255, 255)
        bar.set(x, top, x + w, top + 26 * u)
        c.drawRoundRect(bar, 13 * u, 13 * u, paint)
        paint.color = color
        bar.set(x, top, x + w * frac.coerceIn(0f, 1f), top + 26 * u)
        c.drawRoundRect(bar, 13 * u, 13 * u, paint)
        paint.color = GREY_BRIGHT
        text(c, value, x + w + 24 * u, top + 24 * u, 28 * u, sans, Paint.Align.LEFT)
        return top + 80 * u
    }

    private fun drawTrack(c: Canvas, t: Track, x: Float, y: Float, u: Float, align: Paint.Align) {
        paint.color = GREY_BRIGHT
        text(c, "♪  " + ellipsize(t.title, 46), x, y, 46 * u, sans, align)
        if (t.artist.isNotBlank()) {
            paint.color = GREY
            text(c, ellipsize(t.artist, 56), x, y + 56 * u, 36 * u, sans, align)
        }
    }

    private fun rarityColor(rarity: String): Int = when (rarity) {
        "uncommon" -> Color.rgb(110, 220, 110)
        "rare" -> Color.rgb(100, 160, 255)
        "epic" -> Color.rgb(190, 110, 255)
        "legendary" -> Color.rgb(255, 180, 50)
        else -> GREY_BRIGHT
    }

    // ── Smoothing helpers ────────────────────────────────────────────────────

    /** 0..1 over [FADE_MS] since [changedMs]; asks for more frames until it reaches 1. */
    private fun progress(nowMs: Long, changedMs: Long): Float {
        val p = ((nowMs - changedMs) / FADE_MS.toFloat()).coerceIn(0f, 1f)
        if (p < 1f) animating = true
        return p
    }

    /** Eases [shown] toward [target]; the first value is taken as is. */
    private fun approach(shown: Float, target: Float, dtMs: Long): Float {
        if (shown < 0f) return target
        val diff = target - shown
        if (abs(diff) < 0.002f) return target
        animating = true
        return shown + diff * (1f - exp(-dtMs / BAR_EASE_MS))
    }

    private fun withAlpha(color: Int, alpha: Float): Int =
        (color and 0x00FFFFFF) or ((alpha * 255f).toInt().coerceIn(0, 255) shl 24)

    private fun updateClock(nowMs: Long) {
        val sec = nowMs / 1000
        if (sec == clockSecond) return
        clockSecond = sec
        val date = Date(nowMs)
        timeText = if (is24) timeFormat.format(date) else timeFormat.format(date) + " " + ampmFormat.format(date).lowercase()
        dateText = dateFormat.format(date)
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, face: Typeface, align: Paint.Align) {
        paint.textSize = size
        paint.typeface = face
        paint.textAlign = align
        c.drawText(s, x, y, paint)
    }

    private fun ellipsize(s: String, max: Int) = if (s.length <= max) s else s.take(max - 1) + "…"

    private fun wrapped(s: String): List<String> {
        wrapCache[s]?.let { return it }
        if (wrapCache.size > 8) wrapCache.clear()
        return wrap(s, 30).also { wrapCache[s] = it }
    }

    private fun wrap(s: String, maxChars: Int): List<String> {
        val lines = mutableListOf<String>()
        var cur = ""
        for (word in s.split(' ')) {
            if (cur.isNotEmpty() && cur.length + 1 + word.length > maxChars) { lines += cur; cur = word }
            else cur = if (cur.isEmpty()) word else "$cur $word"
        }
        if (cur.isNotEmpty()) lines += cur
        return lines
    }

    private companion object {
        val GREY_BRIGHT = Color.rgb(200, 200, 205)
        val GREY = Color.rgb(130, 130, 138)
        val GREY_DIM = Color.rgb(70, 70, 76)
        val ORANGE = Color.rgb(255, 140, 0)
        const val DRIFT_X_SECONDS = 17 * 60.0
        const val DRIFT_Y_SECONDS = 23 * 60.0
        const val FADE_MS = 700L
        const val BAR_EASE_MS = 350f
    }
}

/** Feeds a [LilguyScreenView]: redraws every second and refreshes save, weather and music. */
internal class LilguyScreenController(private val context: Context, private val view: LilguyScreenView) {
    private var scope: CoroutineScope? = null

    fun start() {
        stop()
        val s = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        scope = s
        // Weather every 15 minutes (every minute until it works), save every minute, music every 3 seconds. Failures keep
        // the previous value on screen; only the first failure of the save shows a message.
        s.launch { while (isActive) { delay(if (refreshWeather()) 15 * 60_000L else 60_000L) } }
        s.launch { while (isActive) { refreshLilguy(); delay(60_000L) } }
        s.launch { while (isActive) { refreshTrack(); delay(3_000L) } }
        // While the screen is up the TV is in use, so the server's 24 h idle timer keeps resetting.
        s.launch { while (isActive) { IdleTimer.shared.touch(); view.postInvalidate(); delay(1_000L) } }
        // Only checks the clock. LilguyRotation decides whether 3 minutes (line) or 5 minutes
        // (face) have really passed, or whether a bar dropped low enough to need a new line now.
        s.launch { while (isActive) { view.data.lilguy?.let { applyRotation(it) }; delay(5_000L) } }
    }

    fun stop() {
        scope?.cancel()
        scope = null
    }

    /** True when the weather was updated; a failure is retried after a minute instead of 15. */
    private suspend fun refreshWeather(): Boolean =
        runCatching { withContext(Dispatchers.IO) { WeatherApi.fetch(context) } }
            .onSuccess { view.data = view.data.copy(weather = it) }
            .onFailure { Log.w(TAG, "Weather failed: ${it.message}") }
            .isSuccess

    private suspend fun refreshLilguy() {
        val code = LilguySettings.saveCode(context)
        if (code == null) { view.data = view.data.copy(lilguy = null, lilguyError = null); return }
        runCatching { withContext(Dispatchers.IO) { LilguyApi.fetch(code) } }
            .onSuccess {
                val r = rotate(it)
                view.data = view.data.copy(lilguy = it, lilguyError = null, line = r.line, face = r.face)
            }
            .onFailure {
                Log.w(TAG, "Lilguy failed: ${it.message}")
                if (view.data.lilguy == null) view.data = view.data.copy(lilguyError = it.message)
            }
    }

    private suspend fun refreshTrack() {
        val track = withContext(Dispatchers.IO) { NowPlaying.current(context) }
        if (track != view.data.track) view.data = view.data.copy(track = track)
    }

    private fun rotate(l: LilguySnapshot): LilguyRotation =
        LilguyRotation.shared.also { it.update(l, System.currentTimeMillis(), Calendar.getInstance().get(Calendar.MONTH) + 1) }

    private fun applyRotation(l: LilguySnapshot) {
        val r = rotate(l)
        val cur = view.data
        if (cur.line != r.line || cur.face != r.face) view.data = cur.copy(line = r.line, face = r.face)
    }

    private companion object { const val TAG = "LilguyScreen" }
}

/** The real Android screensaver ("Daydream"): pick it in Settings → Device Preferences → Screen saver. */
class LilguyDreamService : DreamService() {
    private var controller: LilguyScreenController? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = false
        isFullscreen = true
        val view = LilguyScreenView(this)
        setContentView(view)
        controller = LilguyScreenController(this, view)
    }

    override fun onDreamingStarted() {
        super.onDreamingStarted()
        controller?.start()
    }

    override fun onDreamingStopped() {
        controller?.stop()
        super.onDreamingStopped()
    }

    override fun onDetachedFromWindow() {
        controller?.stop()
        controller = null
        super.onDetachedFromWindow()
    }
}

/**
 * The same screen as a normal activity. This is what the "screensaver" macro step starts, because
 * a macro can launch an activity on demand but cannot start a dream. Any key press leaves it
 * (volume keys excepted), which is also how a following macro step like "home" gets out.
 */
class LilguyScreenActivity : Activity() {
    private var controller: LilguyScreenController? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val view = LilguyScreenView(this)
        view.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        setContentView(view)
        controller = LilguyScreenController(this, view)
    }

    override fun onStart() { super.onStart(); controller?.start() }
    override fun onStop() { controller?.stop(); super.onStop() }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE) return super.onKeyDown(keyCode, event)
        finish()
        return true
    }
}
