package com.porter.tvremote

import android.content.Context
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

internal data class Weather(val temperature: Int, val unitSymbol: String, val summary: String) {
    fun display(): String = "$temperature$unitSymbol  $summary"
}

/**
 * Current weather from Open-Meteo (free, no API key). The location is the one saved in
 * settings, otherwise the TV's public IP is looked up the way lilguy does it, so no location
 * permission is needed.
 */
internal object WeatherApi {
    private val json = Json { ignoreUnknownKeys = true }

    @Volatile private var ipLocation: Pair<Double, Double>? = null

    fun fetch(context: Context): Weather {
        val (lat, lon) = LilguySettings.location(context) ?: ipLocation ?: lookUpIp().also { ipLocation = it }
        val fahrenheit = LilguySettings.units(context) == LilguySettings.FAHRENHEIT
        val unit = if (fahrenheit) "fahrenheit" else "celsius"
        val body = get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true&temperature_unit=$unit")
        val current = json.parseToJsonElement(body).jsonObject["current_weather"]?.jsonObject
            ?: error("No weather in response")
        val temp = current["temperature"]?.jsonPrimitive?.doubleOrNull ?: error("No temperature")
        val code = current["weathercode"]?.jsonPrimitive?.doubleOrNull?.toInt() ?: -1
        return Weather(temp.roundToInt(), if (fahrenheit) "°F" else "°C", describe(code))
    }

    /** Tries one free IP lookup service, then another, so a single outage or rate limit isn't fatal. */
    private fun lookUpIp(): Pair<Double, Double> {
        var failure: Throwable? = null
        for (url in listOf("https://ipapi.co/json/", "https://ipwho.is/")) {
            try {
                val o = json.parseToJsonElement(get(url)).jsonObject
                val lat = o["latitude"]?.jsonPrimitive?.doubleOrNull
                val lon = o["longitude"]?.jsonPrimitive?.doubleOrNull
                if (lat != null && lon != null) return lat to lon
            } catch (e: Exception) {
                failure = e
            }
        }
        error("Could not work out your location" + (failure?.message?.let { " ($it)" } ?: ""))
    }

    /** WMO weather interpretation codes, as used by Open-Meteo. */
    internal fun describe(code: Int): String = when (code) {
        0 -> "Clear"
        1 -> "Mostly clear"
        2 -> "Partly cloudy"
        3 -> "Overcast"
        45, 48 -> "Fog"
        51, 53, 55, 56, 57 -> "Drizzle"
        61, 63, 65, 66, 67 -> "Rain"
        71, 73, 75, 77 -> "Snow"
        80, 81, 82 -> "Showers"
        85, 86 -> "Snow showers"
        95, 96, 99 -> "Thunderstorm"
        else -> "—"
    }

    private fun get(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode} from ${URL(url).host}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
