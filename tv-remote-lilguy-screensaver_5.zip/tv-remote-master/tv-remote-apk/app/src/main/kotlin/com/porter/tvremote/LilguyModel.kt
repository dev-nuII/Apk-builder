package com.porter.tvremote

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import java.time.Instant
import java.util.Random

/**
 * How he is doing right now, judged from the same numbers the bars show. The face and the line
 * both follow this, so they can't disagree with the HUNGER and HP bars on screen.
 */
internal data class Vibe(val mood: Int, val hungry: Boolean, val hurt: Boolean)

/** One piece of loot. Slots are weapon / armor / item; rarities common..legendary. */
internal data class GearPiece(val slot: String, val rarity: String, val bonus: Int)

/**
 * Read-only view of a lilguy save, as returned by lilguy-notifier's `/api/load-save`.
 * Nothing here ever writes back: you can look at him, but you can't feed him from the TV.
 */
internal data class LilguySnapshot(
    val mood: Int,                    // 1 happy, 2 neutral, 3 angry
    val hunger: Double,               // 0..20 as last saved; use [hungerAt] for "now"
    val lastHungerCheckMs: Long?,
    val hp: Int,
    val maxHp: Int,
    val level: Int,
    val dmg: Int,
    val bond: Double,
    val gear: List<GearPiece>,
    val unlockedTiers: Set<Int>,      // bond thresholds, e.g. 500 = "wink" tier
    val sleepWakeAtMs: Long?,
    val username: String?,
) {
    /** Same rule the game uses on load: asleep while the wake-up time is still ahead. */
    fun isSleeping(nowMs: Long): Boolean = sleepWakeAtMs != null && nowMs < sleepWakeAtMs

    /** Saved hunger minus one point per hour since the last check, like startup.js does. */
    fun hungerAt(nowMs: Long): Double {
        val since = lastHungerCheckMs ?: return hunger.coerceIn(0.0, MAX_HUNGER)
        val hours = ((nowMs - since) / 3_600_000.0).coerceAtLeast(0.0)
        return (hunger - hours).coerceIn(0.0, MAX_HUNGER)
    }

    /**
     * The saved mood is only rolled once a day by the game, but the bars move all day, so a low
     * bar pulls his mood down: at or under 30% he is upset, at or under 60% he is at best neutral.
     */
    fun vibe(nowMs: Long): Vibe {
        val h = hungerAt(nowMs) / MAX_HUNGER
        val p = hp.toDouble() / maxHp
        val worst = minOf(h, p)
        val floor = when {
            worst <= LOW_FRACTION -> 3
            worst <= MID_FRACTION -> 2
            else -> 1
        }
        return Vibe(maxOf(mood, floor), hungry = h <= LOW_FRACTION, hurt = p <= LOW_FRACTION)
    }

    fun gearIn(slot: String): GearPiece? = gear.firstOrNull { it.slot == slot }

    fun bondLabel(): String = when {
        bond >= 100 * BOND_SCALE -> "inseparable"
        bond >= 60 * BOND_SCALE -> "close"
        bond >= 30 * BOND_SCALE -> "comfortable"
        bond >= 10 * BOND_SCALE -> "getting to know each other"
        else -> "just met"
    }

    companion object {
        const val MAX_HUNGER = 20.0
        const val BOND_SCALE = 50
        const val LOW_FRACTION = 0.3   // the HUNGER bar turns red under 6 / 20
        const val MID_FRACTION = 0.6

        private val json = Json { ignoreUnknownKeys = true }

        /** Parses the `/api/load-save` response body: `{ "save": {...}, "saveCode": "..." }`. */
        fun parseResponse(body: String): LilguySnapshot {
            val root = json.parseToJsonElement(body).jsonObject
            val save = (root["save"] as? JsonObject) ?: error("Response has no save")
            return fromSave(save)
        }

        fun fromSave(save: JsonObject): LilguySnapshot = LilguySnapshot(
            mood = save.int("mood", 2).coerceIn(1, 3),
            hunger = save.double("hunger", MAX_HUNGER),
            lastHungerCheckMs = (save["last_hunger_check"] as? JsonPrimitive)?.contentOrNull()?.let(::parseInstantMs),
            hp = save.int("hp", 5),
            maxHp = save.int("max_hp", 5).coerceAtLeast(1),
            level = save.int("level", 0),
            dmg = save.int("dmg", 1),
            bond = save.double("bond", 0.0),
            gear = parseGear(save["gear"]),
            unlockedTiers = parseTiers(save["unlocked_tiers"]),
            sleepWakeAtMs = save.double("sleep_wake_at", Double.NaN).takeIf { !it.isNaN() && it > 0 }?.toLong(),
            username = (save["username"] as? JsonPrimitive)?.contentOrNull()?.takeIf { it.isNotBlank() },
        )

        private fun JsonPrimitive.contentOrNull(): String? = if (isString) content else null

        private fun JsonObject.double(key: String, default: Double): Double =
            (this[key] as? JsonPrimitive)?.doubleOrNull ?: default

        private fun JsonObject.int(key: String, default: Int): Int = double(key, default.toDouble()).toInt()

        private fun parseInstantMs(text: String): Long? =
            runCatching { Instant.parse(text).toEpochMilli() }.getOrNull()

        /** Firebase returns arrays as JSON arrays, or as objects when entries are sparse. */
        private fun elements(el: JsonElement?): List<JsonElement> = when (el) {
            is JsonArray -> el.toList()
            is JsonObject -> el.values.toList()
            else -> emptyList()
        }

        private fun parseGear(el: JsonElement?): List<GearPiece> = elements(el).mapNotNull { item ->
            val o = item as? JsonObject ?: return@mapNotNull null
            val slot = (o["slot"] as? JsonPrimitive)?.contentOrNull() ?: return@mapNotNull null
            val rarity = (o["rarity"] as? JsonPrimitive)?.contentOrNull() ?: "common"
            GearPiece(slot, rarity, o.int("bonus", 0))
        }

        private fun parseTiers(el: JsonElement?): Set<Int> =
            elements(el).mapNotNull { (it as? JsonPrimitive)?.doubleOrNull?.toInt() }.toSet()
    }
}

/** The lines he says, copied from lilguy's state-data.js so the TV sounds like the game. */
internal object LilguySpeech {
    private val happy = listOf(
        "hehe :)", "today's a good day", "glad you're here",
        "i love you <3", "i like it when you're around",
        "thank you for spending time with me",
    )
    private val neutral = listOf(
        "...", "just vibing", "hm", "wassup.",
        "today felt normal. in a good way",
        "do you ever wonder why theres so much violence",
        "i've been thinking about that walk earlier",
        "do you ever wonder what's outside the window",
        "sometimes i just sit here and think",
        "someday...ill see others like me",
    )
    private val angry = listOf(">:(", "not now.", ">:{", "leave me alone.", "its lonely when you leave me")

    // Not in the game: used only when a bar is low, so what he says matches what the bar shows.
    private val hungry = listOf("my tummy's rumbling", "is it snack time yet?", "i could really use something to eat", "so hungry...")
    private val hurt = listOf("ow. i don't feel so good", "i need to rest a bit", "that hurt more than i thought")

    private val season = mapOf(
        "winter" to listOf("it's cold out there, huh", "i wish i could see snow", "let's stay inside today"),
        "spring" to listOf("everything is growing again", "i can smell the flowers. probably.", "spring always feels hopeful"),
        "summer" to listOf("it's so warm out", "summer's my favorite honestly", "i bet its bright outside right now"),
        "fall" to listOf("the leaves must be falling", "fall always feels a little nostalgic", "cozy season, right?"),
    )

    /** Bond thresholds (bond points) that unlock extra happy lines. */
    private val tiers = listOf(
        Tier(10 * LilguySnapshot.BOND_SCALE, listOf("hehe, i feel closer to you now", "something feels different. good different.")),
        Tier(30 * LilguySnapshot.BOND_SCALE, listOf("i wanna dance!!", "watch this!")),
        Tier(60 * LilguySnapshot.BOND_SCALE, listOf("you're my favorite person, you know that?", "i really mean it. thank you.")),
        Tier(100 * LilguySnapshot.BOND_SCALE, listOf("we've really been through it together huh", "i wouldn't trade this for anything")),
    )

    private class Tier(val threshold: Int, val lines: List<String>)

    fun seasonOf(month: Int): String = when (month) {
        12, 1, 2 -> "winter"
        3, 4, 5 -> "spring"
        6, 7, 8 -> "summer"
        else -> "fall"
    }

    /**
     * A low bar always wins: hungry or hurt lines, never cheerful ones. Otherwise it mirrors
     * tick.js: a quarter of the time a seasonal line (never when upset), else a mood line,
     * where the mood is the one [LilguySnapshot.vibe] works out from the bars.
     */
    fun pick(s: LilguySnapshot, month: Int, nowMs: Long, random: Random = Random()): String {
        val v = s.vibe(nowMs)
        val needs = buildList {
            if (v.hungry) addAll(hungry)
            if (v.hurt) addAll(hurt)
        }
        if (needs.isNotEmpty()) return needs.random(random)
        if (random.nextInt(4) == 0 && v.mood != 3) return season.getValue(seasonOf(month)).random(random)
        val pool = when (v.mood) {
            1 -> happy + unlockedLines(s)
            2 -> neutral
            else -> angry
        }
        return pool.random(random)
    }

    private fun unlockedLines(s: LilguySnapshot): List<String> =
        tiers.filter { it.threshold in s.unlockedTiers }.flatMap { it.lines }

    private fun <T> List<T>.random(r: Random): T = this[r.nextInt(size)]
}

/**
 * His faces. One is picked per 5-minute slot. The two walking faces carry double weight, so they
 * come up most; the other four are rarer. Cheerful faces only show while he is in a good mood.
 */
internal object LilguyFace {
    const val SLOT_MS = 5 * 60_000L

    private class Entry(val face: String, val weight: Int, val happyOnly: Boolean = false)

    private val entries = listOf(
        Entry("<_", 2), Entry("_>", 2),
        Entry("o7", 1), Entry("o/", 1, happyOnly = true),
        Entry("^_^", 1, happyOnly = true), Entry("O_O", 1),
    )

    fun canShow(face: String, mood: Int): Boolean =
        entries.any { it.face == face && (!it.happyOnly || mood == 1) }

    fun pick(mood: Int, random: Random = Random()): String {
        val pool = entries.filter { !it.happyOnly || mood == 1 }
        var roll = random.nextInt(pool.sumOf { it.weight })
        for (e in pool) {
            if (roll < e.weight) return e.face
            roll -= e.weight
        }
        return pool.first().face
    }
}

/**
 * Decides when his line and face change, so the screen never changes them faster than intended:
 * a new line only after [LINE_INTERVAL_MS], a new face only after [LilguyFace.SLOT_MS]. The one
 * exception is his vibe changing (a bar drops low, his mood flips), which re-picks right away so
 * the line and face never contradict the bars. One shared instance lives as long as the app does,
 * so leaving and re-entering the screensaver doesn't reshuffle him either.
 */
internal class LilguyRotation(private val random: Random = Random()) {
    @Volatile var line: String = "..."; private set
    @Volatile var face: String = "<_"; private set

    private var lineAtMs: Long? = null
    private var faceAtMs: Long? = null
    private var vibe: Vibe? = null

    @Synchronized
    fun update(s: LilguySnapshot, nowMs: Long, month: Int) {
        val v = s.vibe(nowMs)
        val vibeChanged = vibe != v
        vibe = v
        if (vibeChanged || due(lineAtMs, nowMs, LINE_INTERVAL_MS)) {
            line = LilguySpeech.pick(s, month, nowMs, random)
            lineAtMs = nowMs
        }
        if (due(faceAtMs, nowMs, LilguyFace.SLOT_MS) || !LilguyFace.canShow(face, v.mood)) {
            face = LilguyFace.pick(v.mood, random)
            faceAtMs = nowMs
        }
    }

    /** True with no previous change, after [intervalMs], or if the clock was set backwards. */
    private fun due(at: Long?, nowMs: Long, intervalMs: Long): Boolean =
        at == null || nowMs - at !in 0 until intervalMs

    companion object {
        const val LINE_INTERVAL_MS = 3 * 60_000L

        val shared = LilguyRotation()
    }
}
