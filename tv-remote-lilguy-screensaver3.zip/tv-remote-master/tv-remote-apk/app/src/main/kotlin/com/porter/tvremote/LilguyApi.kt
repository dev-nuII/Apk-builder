package com.porter.tvremote

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL

/** What the screensaver needs to remember between runs. */
internal object LilguySettings {
    private const val KEY_CODE = "lilguy_save_code"
    private const val KEY_UNITS = "weather_units"
    private const val KEY_LAT = "weather_lat"
    private const val KEY_LON = "weather_lon"

    const val FAHRENHEIT = "fahrenheit"
    const val CELSIUS = "celsius"

    fun saveCode(context: Context): String? = Preferences.of(context).getString(KEY_CODE, null)

    fun setSaveCode(context: Context, code: String?) {
        Preferences.of(context).edit().apply {
            if (code == null) remove(KEY_CODE) else putString(KEY_CODE, code)
        }.apply()
    }

    fun units(context: Context): String =
        Preferences.of(context).getString(KEY_UNITS, FAHRENHEIT)?.takeIf { it == CELSIUS } ?: FAHRENHEIT

    fun setUnits(context: Context, units: String) {
        require(units == FAHRENHEIT || units == CELSIUS) { "Invalid units" }
        Preferences.of(context).edit().putString(KEY_UNITS, units).apply()
    }

    /** Optional fixed location. Without one, the TV's public IP is used, like lilguy does. */
    fun location(context: Context): Pair<Double, Double>? {
        val p = Preferences.of(context)
        if (!p.contains(KEY_LAT) || !p.contains(KEY_LON)) return null
        return p.getFloat(KEY_LAT, 0f).toDouble() to p.getFloat(KEY_LON, 0f).toDouble()
    }

    fun setLocation(context: Context, lat: Double?, lon: Double?) {
        Preferences.of(context).edit().apply {
            if (lat == null || lon == null) {
                remove(KEY_LAT); remove(KEY_LON)
            } else {
                require(lat in -90.0..90.0 && lon in -180.0..180.0) { "Invalid location" }
                putFloat(KEY_LAT, lat.toFloat()); putFloat(KEY_LON, lon.toFloat())
            }
        }.apply()
    }
}

/** Read-only client for lilguy-notifier. */
internal object LilguyApi {
    const val BASE_URL = "https://lilguy-notifier.vercel.app"
    private const val COOKIE = "lilguy_save_code"
    private val CODE_RE = Regex("^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$")

    fun normalizeCode(raw: String): String = raw.trim().uppercase()

    fun isValidCode(code: String): Boolean = CODE_RE.matches(code)

    /**
     * Loads the save for [code]. The server identifies a save by the `lilguy_save_code` cookie,
     * so that is what is sent. Careful: for a code it does not know, `/api/load-save` creates a
     * fresh save and answers with a *different* code. That is detected and reported as "not
     * found", but the stray save still exists on the server, so [isValidCode] is checked first.
     */
    fun fetch(code: String): LilguySnapshot {
        require(isValidCode(code)) { "That doesn't look like a save code (ABCD-EFGH-JKLM)" }
        val conn = URL("$BASE_URL/api/load-save").openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("Cookie", "$COOKIE=$code")
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode !in 200..299) error("Lilguy server returned ${conn.responseCode}")
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val returned = Regex("\"saveCode\"\\s*:\\s*\"([^\"]*)\"").find(body)?.groupValues?.get(1)
            if (returned != null && returned != code) error("Save code not found")
            return LilguySnapshot.parseResponse(body)
        } finally {
            conn.disconnect()
        }
    }
}
