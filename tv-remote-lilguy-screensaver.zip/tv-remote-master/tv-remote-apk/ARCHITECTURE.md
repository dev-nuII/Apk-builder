# TV Remote APK — a guided tour

Where everything lives, how the pieces talk to each other, and recipes for the changes you're
most likely to want. Paths are relative to `tv-remote-apk/`. Kotlin lives in
`app/src/main/kotlin/com/porter/tvremote/`, shortened below to `kt/`.

---

## 1. The big picture

```
 Phone / laptop browser                  Yatse / Kore (phone)
        │  HTTP :8080                           │  UDP :5600
        ▼                                       ▼
 ┌───────────────────────────── RemoteService (foreground service) ─────────────────────┐
 │  HttpServer (Ktor)  ──►  MacroRunner ──┐          YatseStarter ──► wake + launch Kodi │
 │     │  serves index.html                │                              │              │
 │     │  /api/* routes                    ▼                              ▼              │
 │     └──────────────────────────►  AdbController  ◄──────────────────────┘              │
 │                                         │  ADB over loopback (127.0.0.1:5555)         │
 └─────────────────────────────────────────┼─────────────────────────────────────────────┘
                                           ▼
                                 the TV's own ADB daemon
                          (input keyevent · am start · dumpsys)

 Lil Guy screensaver (separate from the server, same app)
   LilguyDreamService ─┐
                       ├─► LilguyScreenView (draws) ◄── LilguyScreenController (refreshes)
   LilguyScreenActivity┘                                   ├─ LilguyApi   → lilguy-notifier on Vercel
     ▲ started by the "screensaver" macro step             ├─ WeatherApi  → Open-Meteo
     │ (via adb "am start")                                └─ NowPlaying  → Android media sessions
```

Two ideas explain most of the code:

1. **Everything the TV "does" goes through `AdbController`.** The app connects back to the TV's own
   ADB daemon, which gives it shell powers (key presses, launching apps). No root needed.
2. **The web remote is a single HTML file** (`index.html`) talking to a small REST API in
   `HttpServer.kt`. Almost every feature is "add a route + add a button".

---

## 2. File map

### Kotlin — the server and remote (original project)

| File | What it is |
|---|---|
| `kt/MainActivity.kt` | The app's launcher screen on the TV: status lights, URL, port −/+ buttons, **Start/Stop Server**. D-pad friendly. Does no remote-control work itself. |
| `kt/RemoteService.kt` | The foreground service that keeps everything alive: starts `HttpServer`, `YatseStarter` and the ADB connection, holds the wake/Wi-Fi locks, shows the notification. Also contains the **24-hour idle shutdown** watchdog. |
| `kt/BootReceiver.kt` | Starts `RemoteService` when the TV boots or the app is updated. |
| `kt/HttpServer.kt` | The Ktor web server. **All `/api/...` routes are in `setupRoutes()`.** Also holds `Preferences` (the app's one SharedPreferences file) and `HttpServerSettings` (the port). |
| `kt/AdbController.kt` | The loopback ADB client. Key methods: `keyEvent()`, `launchApp()`, `shell()`, `goHome()`, `sendText()`. The `APPS` map (youtube, netflix, …) lives here. |
| `kt/YatseStarter.kt` | UDP listener on :5600 for Yatse/Kore wake packets → wakes the TV and launches Kodi. Never interprets packet contents as commands. |
| `kt/Macros.kt` | Macro storage and playback: `Macro` (name + list of steps), `MacroStore` (validation, saving), `MacroRunner` (plays steps on a background thread). |

### Kotlin — added for the Lil Guy screensaver

| File | What it is |
|---|---|
| `kt/LilguyModel.kt` | Pure logic, no Android. `LilguySnapshot` parses the save and works out what is true *now*: current hunger, whether he is asleep, and `feelingAt()` (hungry / angry / neutral / happy, from the hunger number and his mood). `LilguySpeech` holds his lines and picks one that fits that feeling. `FaceScheduler` decides his face (see section 4). |
| `kt/LilguyApi.kt` | `LilguySettings` (saved code, °F/°C, optional fixed location) and `LilguyApi` (fetches the save from your Vercel app). **`BASE_URL` is here.** |
| `kt/WeatherApi.kt` | Current weather from Open-Meteo; location from the saved setting, else the TV's public IP. |
| `kt/NowPlaying.kt` | Reads the playing track from Android's media sessions. `NowPlayingListener` exists only because Android demands one for that permission. |
| `kt/LilguyScreen.kt` | `LilguyScreenView` (all the drawing: awake and sleeping layouts, fades, eased hunger bar), `LilguyScreenController` (refresh loops, and the 3-minute line timer), `LilguyDreamService` (the system screensaver), `LilguyScreenActivity` (same screen, launched by macros). |
| `kt/TrackpadService.kt` | The trackpad: an accessibility service that draws a mouse cursor on the TV and performs tap, long-press and scroll gestures at it. Also `TrackpadSetup`, which switches the service on over ADB. |
| `kt/IdleTimer.kt` | "When was the server last used?" Reset by web requests, macros and the screensaver. |

### Web UI

| File | What it is |
|---|---|
| `app/src/main/assets/index.html` | The whole web remote: HTML, CSS and JS in one file. Buttons call `/api/...`. The **Macros** card and **Lil Guy screensaver** card are near the bottom of the page and their scripts at the end of the file. (Separate from `../scripts/static/index.html`, which belongs to the Python/PC version.) |

### Android config and resources

| File | What it is |
|---|---|
| `app/src/main/AndroidManifest.xml` | Declares permissions, the activities, the services (`RemoteService`, the screensaver, the notification listener) and the boot receiver. **New Android components must be registered here.** |
| `app/src/main/res/layout/activity_main.xml` | Layout of `MainActivity`. |
| `app/src/main/res/values/strings.xml` | UI text for `MainActivity` and the notification. |
| `app/src/main/res/xml/trackpad_service.xml` | Accessibility-service settings for the trackpad (gestures allowed, no events read). |
| `app/src/main/res/values/themes.xml`, `colors.xml` | Dark theme. |
| `app/src/main/res/drawable/*.xml` | Button, card and status-dot shapes, and the notification icon. |
| `app/src/main/res/mipmap-*`, `drawable*/tv_banner.png` | App icon and Android TV launcher banner. |

### Build, tests and publishing

| File | What it is |
|---|---|
| `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties` | Project-level Gradle setup. |
| `app/build.gradle.kts` | **Version number** (`versionCode`, `versionName`), dependencies, signing. |
| `app/proguard-rules.pro` | Shrinker rules for release builds. |
| `app/src/test/kotlin/.../*Test.kt` | Unit tests: `MacroStoreTest`, `LilguyModelTest`, `IdleTimerTest`, `HttpServerPortTest`, `YatsePacketHandlerTest`, `WakeAndLaunchKodiActionTest`. |
| `SETUP.md` | Build and install guide. |
| `PLAY_STORE_PUBLISHING.md`, `fdroid/`, `store-assets/`, `../fastlane/` | Store listings and metadata. Not part of the app. |

---

## 3. The API (in `HttpServer.setupRoutes()`)

| Route | What it does |
|---|---|
| `GET /` | Serves `index.html` |
| `POST /api/key/{code}` | Sends an Android keycode |
| `POST /api/launch/{name}` | Launches an app from `AdbController.APPS`, or `home`, or any package name |
| `POST /api/text` | Types text into the focused field |
| `GET/POST /api/macros`, `DELETE /api/macros/{name}`, `POST /api/macros/{name}/run` | Macros. `POST` saves *or edits*: a macro with the same name is replaced in place |
| `GET/POST /api/lilguy` | Read or set the save code (shown masked) and °F/°C |
| `POST /api/lilguy/music-access` | Grants the notification-listener permission via ADB |
| `POST /api/screensaver/start` | Opens the Lil Guy screen now |
| `GET /api/trackpad`, `POST /api/trackpad/enable` | Is the trackpad service on / switch it on over ADB |
| `POST /api/trackpad/move` `{dx, dy}`, `/scroll` `{dy}`, `/click`, `/longpress` | Drive the cursor. Answer 409 until the service is enabled |
| `GET /api/state`, `/api/adb`, `/api/config` | Screen/app state, ADB health, TV name |

Every request resets the idle timer (`intercept(ApplicationCallPipeline.Setup)` at the top of `start()`).

---

## 4. Recipes

### Add a new macro step (e.g. `mute`)
1. `kt/Macros.kt` — add it to `KEYCODES` (`"mute" to 164`) if it's a key press. Keycodes: `../docs/keycodes.md`.
   For something that isn't a key (like `screensaver`), add a constant, accept it in `isValidStep()`, and handle it in `MacroRunner.start()`.
2. `index.html` — add a button in the `.macro-pad` block: `<button onclick="mAdd('mute')">Mute</button>`.
3. `MacroStoreTest.kt` — add one assertion.

### Add a new API route
1. `kt/HttpServer.kt` — add inside `setupRoutes()`. For anything that touches the TV, wrap it in `adbCall(call) { ... }` so errors come back as JSON.
2. Call it from `index.html` with `fetch('/api/...')`.
3. Add a line to the route list in the KDoc at the top of `HttpServer.kt`.

### Add an app shortcut
Add it to `AdbController.APPS` (`"hulu" to "com.hulu.livingroom/..."`). It then works from `POST /api/launch/hulu` and the CLI. Find an app's activity with `adb shell dumpsys package <package> | grep -i activity`.

### Add something to the screensaver
All drawing is in `LilguyScreenView` in `kt/LilguyScreen.kt`:
- `drawAwake()` — the full screen. Add lines with `text(canvas, "...", x, y, size, typeface, align)`. Sizes use `u` (1 = 1/1080 of the screen height), so layouts scale to any TV.
- `drawSleeping()` — the black screen. Keep it minimal: that's the point.
- New data: add a field to `ScreenData`, fill it in `LilguyScreenController` (copy the `refreshWeather()` pattern), draw it.
- A stat from lilguy's save: add it to `LilguySnapshot.fromSave()` in `kt/LilguyModel.kt` (the save's field names are in lilguy-notifier's `api/save-game.js`, `ALLOWED_FIELDS`), then draw it.

### Change how he looks or talks
- **Faces:** `FaceScheduler.COMMON` (resting faces and their weights) and `FaceScheduler.RARE` (flash faces) in `kt/LilguyModel.kt`. Each 5-minute slot has one resting face and one 30-second flash; change `SLOT_MS` / `FLASH_MS` to retime.
- **Lines:** the lists in `LilguySpeech`. `hungry` lines are not from the game; they were written so his words match a low hunger bar.
- **When he counts as hungry:** `HUNGRY_AT` in `LilguySnapshot`.
- **How often the line changes:** `LINE_INTERVAL_MS` in `LilguyScreenController` (3 minutes).
- **Smoothness:** `FRAME_MS` (about 30 fps awake), `FACE_FADE_MS`, `LINE_FADE_MS`, and the `4f` in `ease()` (higher = bars catch up faster), all in `LilguyScreenView`.
- **The orange credit line:** search for "made with Claude" in `drawAwake()`.

### Tune the trackpad
Cursor size, hide delay and gesture lengths are constants at the bottom of `TrackpadService`. Pointer speed is the slider in the page (`tp-speed`). Two-finger tap sends Back (`/api/key/4`); change it at the end of the `touchend` handler in `index.html`.

### Add a new setting
1. Getter/setter in `LilguySettings` (`kt/LilguyApi.kt`) — it uses the app's `Preferences`.
2. Expose it in `LilguyConfig` / `LilguyBody` and the `/api/lilguy` routes in `HttpServer.kt`.
3. Add a control in the **Lil Guy screensaver** card of `index.html`.

### Change the idle shutdown
`IdleTimer.DEFAULT_TIMEOUT_MS` in `kt/IdleTimer.kt` (default 24 h). The check runs every 10 minutes, set by `IDLE_CHECK_INTERVAL_MS` in `RemoteService.kt`. To never shut down, delete the `startIdleWatchdog()` call in `RemoteService.onCreate()`.

### Point at a different lilguy server
`LilguyApi.BASE_URL` in `kt/LilguyApi.kt`.

---

## 5. Building and testing

```
./gradlew testDebugUnitTest     # unit tests
./gradlew assembleDebug         # debug APK → app/build/outputs/apk/debug/
```

Needs the Android SDK and JDK 21. If a build fails, the Kotlin error line looks like
`e: file:///…/LilguyScreen.kt:128:36 message` — file, line, column.

## 6. Good to know

- **Why unit tests avoid Android classes.** Plain JUnit tests can't use `Context` or `org.json`. That's why `LilguyModel.kt` uses kotlinx.serialization and `IdleTimer` takes a clock lambda: both stay testable.
- **The ADB prompt.** The first connection makes the TV ask "Allow USB debugging?". Choose "Always allow".
- **The web remote is unauthenticated.** Anyone on your LAN can use it. Keep it off the internet.
- **`LilguyScreenActivity` is exported on purpose.** Macros start it through `am start` from the ADB shell, which counts as another app. It only displays things.
- **A macro can't turn the screensaver off by itself.** Any key closes it, so follow the `screensaver` step with `back` or `home` if you want that.
- **The trackpad is a touch emulator.** Clicks are tap gestures at the cursor, so apps that ignore touch input (many leanback apps) won't react. Browsers, Settings and most phone-style apps do. Keep using the D-pad for the rest.
- **Accessibility and the Play Store.** Google requires a declaration to publish an app that uses `AccessibilityService`. F-Droid and sideloading are unaffected. If you publish to Play, say so in `PLAY_STORE_PUBLISHING.md`'s checklist or remove `TrackpadService`.
- **Lilguy's `/api/load-save` creates a new save for an unknown code.** The app checks the code's format first. See the note in `LilguyApi.fetch()`.
