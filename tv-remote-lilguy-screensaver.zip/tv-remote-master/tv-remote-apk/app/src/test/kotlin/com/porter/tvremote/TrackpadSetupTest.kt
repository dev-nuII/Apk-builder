package com.porter.tvremote

import org.junit.Assert.assertEquals
import org.junit.Test

class TrackpadSetupTest {
    private val me = "com.porter.tvremote/com.porter.tvremote.TrackpadService"

    @Test fun addsToAnEmptyOrNullSetting() {
        assertEquals(me, TrackpadSetup.withComponent(null, me))
        assertEquals(me, TrackpadSetup.withComponent("", me))
        assertEquals(me, TrackpadSetup.withComponent("null", me))
    }

    @Test fun keepsOtherEnabledServices() {
        assertEquals("a/b:$me", TrackpadSetup.withComponent("a/b", me))
        assertEquals("a/b:c/d:$me", TrackpadSetup.withComponent("a/b:c/d\n", me))
    }

    @Test fun doesNotAddItTwice() {
        assertEquals("a/b:$me", TrackpadSetup.withComponent("a/b:$me", me))
    }
}
