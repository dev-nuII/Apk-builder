package com.porter.tvremote

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class LilguyModelTest {
    // Shaped like the current /api/load-save response: the game no longer has hp, level or gear.
    private val body = """
        {"saveCode":"ABCD-EFGH-JKLM","dev":false,"save":{
          "mood":1,"hunger":18,"last_hunger_check":"2026-10-20T12:00:00.000Z",
          "bond":600,"streak":4,"unlocked_tiers":[500],"sleep_wake_at":null,"username":"Porter"}}
    """.trimIndent()

    @Test fun parsesSave() {
        val s = LilguySnapshot.parseResponse(body)
        assertEquals(1, s.mood)
        assertEquals(4, s.streak)
        assertEquals("Porter", s.username)
        assertNull(s.sleepWakeAtMs)
        assertEquals("getting to know each other", s.bondLabel()) // 600 >= 10 * 50, < 30 * 50
    }

    @Test fun missingFieldsFallBackToSafeDefaults() {
        val s = LilguySnapshot.parseResponse("""{"save":{}}""")
        assertEquals(2, s.mood)
        assertEquals(0, s.streak)
        assertEquals(LilguySnapshot.MAX_HUNGER, s.hungerAt(0), 0.001)
    }

    @Test fun oldSavesWithRpgFieldsStillParse() {
        val s = LilguySnapshot.parseResponse("""{"save":{"mood":2,"hp":3,"level":2,"gear":[{"slot":"armor"}]}}""")
        assertEquals(2, s.mood)
    }

    @Test fun hungerDrainsOnePerHourAndClamps() {
        val s = LilguySnapshot.parseResponse(body)
        val start = java.time.Instant.parse("2026-10-20T12:00:00Z").toEpochMilli()
        assertEquals(18.0, s.hungerAt(start), 0.001)
        assertEquals(15.0, s.hungerAt(start + 3 * 3_600_000L), 0.001)
        assertEquals(0.0, s.hungerAt(start + 40 * 3_600_000L), 0.001)
        assertEquals(18.0, s.hungerAt(start - 5 * 3_600_000L), 0.001) // clock skew never raises it
    }

    @Test fun sleepingOnlyWhileWakeTimeIsAhead() {
        val s = LilguySnapshot.parseResponse("""{"save":{"sleep_wake_at":2000}}""")
        assertTrue(s.isSleeping(1999))
        assertFalse(s.isSleeping(2000))
        assertFalse(LilguySnapshot.parseResponse(body).isSleeping(1))
    }

    @Test fun codeValidation() {
        assertEquals("ABCD-EFGH-JKLM", LilguyApi.normalizeCode("  abcd-efgh-jklm "))
        assertTrue(LilguyApi.isValidCode("ABCD-EFGH-JKLM"))
        assertFalse(LilguyApi.isValidCode("ABCDEFGHJKLM"))
        assertFalse(LilguyApi.isValidCode("ABCD-EFGH-JKL"))
        assertFalse(LilguyApi.isValidCode("dev"))
    }

    @Test fun speechAndSeasons() {
        assertEquals("winter", LilguySpeech.seasonOf(12))
        assertEquals("fall", LilguySpeech.seasonOf(10))
        val now = java.time.Instant.parse("2026-10-20T12:00:00Z").toEpochMilli()
        val s = LilguySnapshot.parseResponse(body)
        repeat(50) { assertNotNull(LilguySpeech.pick(s, 10, now, Random(it.toLong()))) }
    }

    @Test fun feelingFollowsHungerAndMood() {
        val start = java.time.Instant.parse("2026-10-20T12:00:00Z").toEpochMilli()
        val hour = 3_600_000L
        val happy = LilguySnapshot.parseResponse(body)
        assertEquals(Feeling.HAPPY, happy.feelingAt(start))
        assertEquals("good", happy.moodLabel(start))
        // 5 hours later hunger has drained from 18 to 13: still happy. At 14 hours it is 4: hungry.
        assertEquals(Feeling.HAPPY, happy.feelingAt(start + 5 * hour))
        assertEquals(Feeling.NEUTRAL, happy.feelingAt(start + 9 * hour)) // 9 left: below the happy line
        assertEquals(Feeling.HUNGRY, happy.feelingAt(start + 14 * hour))
        assertTrue(happy.isDistressed(start + 14 * hour))
        assertEquals("bad", happy.moodLabel(start + 14 * hour))
        val angry = LilguySnapshot.parseResponse("""{"save":{"mood":3,"hunger":15}}""")
        assertEquals(Feeling.ANGRY, angry.feelingAt(0))
        assertTrue(angry.isDistressed(0))
        assertEquals(Feeling.NEUTRAL, LilguySnapshot.parseResponse("""{"save":{"mood":2,"hunger":15}}""").feelingAt(0))
    }

    @Test fun sleepText() {
        val s = LilguySnapshot.parseResponse("""{"save":{"sleep_wake_at":${2 * 3_600_000L + 5 * 60_000L}}}""")
        assertEquals("sleeping (back in ~2h 5m)", s.sleepText(0))
        assertEquals("awake", s.sleepText(3 * 3_600_000L))
        assertEquals("awake", LilguySnapshot.parseResponse(body).sleepText(0))
    }

    @Test fun hungryLinesMatchHowHeFeels() {
        val start = java.time.Instant.parse("2026-10-20T12:00:00Z").toEpochMilli()
        val hungry = LilguySnapshot.parseResponse(body.replace("\"hunger\":18", "\"hunger\":2"))
        val said = (0 until 200).map { LilguySpeech.pick(hungry, 10, start, Random(it.toLong())) }.toSet()
        assertTrue(said.all { it in setOf("my tummy is making noises", "i could really go for a snack", "so hungry...", "i'm getting kind of hungry", "is it dinner time yet?") })
    }
}

class FaceSchedulerTest {
    private val rare = setOf("o7", "o/", "^_^", "O_O")
    private val cheerful = setOf("o7", "o/", "^_^")
    private fun start(slot: Int) = 1_700_000_000_000L / FaceScheduler.SLOT_MS * FaceScheduler.SLOT_MS + slot * FaceScheduler.SLOT_MS

    /** Faces seen across one slot, sampled every 5 seconds. */
    private fun seen(f: FaceScheduler, slot: Int, distressed: Boolean = false): List<String> =
        (0 until 60).map { f.faceAt(start(slot) + it * 5_000L, distressed) }

    @Test fun eachSlotRestsOnOneCommonFaceWithOneRareFlash() {
        val f = FaceScheduler(Random(1))
        repeat(40) { slot ->
            val faces = seen(f, slot)
            val flashes = faces.filter { it in rare }.toSet()
            val resting = faces.filter { it !in rare }.toSet()
            assertEquals("slot $slot", 1, flashes.size)
            assertEquals("slot $slot", 1, resting.size)
            assertTrue(resting.single() in setOf("<_", "_>"))
        }
    }

    @Test fun commonFacesAreWeightedAndEachRareFaceFlashesAboutTwicePer40Minutes() {
        val f = FaceScheduler(Random(7))
        val resting = mutableMapOf<String, Int>()
        val flashes = mutableMapOf<String, Int>()
        val slots = 4000
        repeat(slots) { slot ->
            val faces = seen(f, slot)
            faces.filter { it !in rare }.toSet().forEach { resting.merge(it, 1, Int::plus) }
            faces.filter { it in rare }.toSet().forEach { flashes.merge(it, 1, Int::plus) }
        }
        assertTrue("<_ more common than _>", resting.getValue("<_") > resting.getValue("_>"))
        val perFortyMinutes = 8.0 // slots in 40 minutes
        for (face in rare) {
            val perWindow = flashes.getValue(face) * perFortyMinutes / slots
            assertEquals(face, 2.0, perWindow, 0.3)
        }
    }

    @Test fun distressedFaceNeverLooksCheerful() {
        val f = FaceScheduler(Random(3))
        repeat(100) { slot ->
            seen(f, slot, distressed = true).forEach { face ->
                assertTrue(face !in cheerful)
                assertTrue(face == FaceScheduler.DISTRESSED || face == "O_O")
            }
        }
    }
}
