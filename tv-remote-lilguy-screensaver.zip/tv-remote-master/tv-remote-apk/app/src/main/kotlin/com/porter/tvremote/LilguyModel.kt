package com.porter.tvremote

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonObject
import java.time.Instant
import java.util.Random

/** What he is feeling, which decides his words and (when bad) his face. */
internal enum class Feeling { HAPPY, NEUTRAL, ANGRY, HUNGRY }

/**
 * Read-only view of a lilguy save, as returned by lilguy-notifier's `/api/load-save`.
 * Nothing here ever writes back: you can look at him, but you can't feed him from the TV.
 */
internal data class LilguySnapshot(
    val mood: Int,                    // 1 happy, 2 neutral, 3 angry
    val hunger: Double,               // 0..20 as last saved; use [hungerAt] for "now"
    val lastHungerCheckMs: Long?,
    val bond: Double,
    val streak: Int,                  // consecutive days he has been visited
    val unlockedTiers: Set<Int>,      // bond thresholds, e.g. 500 = "wink" tier
    val sleepWakeAtMs: Long?,
    val username: String?,
) {
    /** Same rule the game uses on load: asleep while the wake-up time is still ahead. */
    fun isSleeping(nowMs: Long): Boolean = sleepWakeAtMs != null && nowMs < sleepWakeAtMs

    /** Saved hunger minus one point per hour since the last check, like startup.js does. */
    fun hungerAt(nowMs: Long): Double {
        val since = lastHungerCheckMs ?: return hunger.coerceIn(0.0, MAX_HUNGER)
        val hours = ((nowMs - since) / 3_600_000.0).coerceAtLeast(0.0)
        return (hunger - hours).coerceIn(0.0, MAX_HUNGER)
    }

    /**
     * How he feels *right now*, from the same numbers the bars show. The save's own `mood` can be
     * hours out of date, which is why his words and face used to disagree with his hunger and HP.
     */
    fun feelingAt(nowMs: Long): Feeling {
        val hunger = hungerAt(nowMs)
        return when {
            hunger <= HUNGRY_AT -> Feeling.HUNGRY
            mood == 3 -> Feeling.ANGRY
            mood == 1 && hunger >= 10.0 -> Feeling.HAPPY
            else -> Feeling.NEUTRAL
        }
    }

    /** True when he should look unwell: hungry, or in the game's "bad" (angry) mood. */
    fun isDistressed(nowMs: Long): Boolean = feelingAt(nowMs).let { it == Feeling.HUNGRY || it == Feeling.ANGRY }

    /** The word the game's idle screen shows after "Mood:" (its `mental_state`). */
    fun moodLabel(nowMs: Long): String = when (feelingAt(nowMs)) {
        Feeling.HAPPY -> "good"
        Feeling.NEUTRAL -> "neutral"
        Feeling.ANGRY, Feeling.HUNGRY -> "bad"
    }

    /** "Sleeping (back in ~2h 5m)" style text is only shown by the game; this is the awake half. */
    fun sleepText(nowMs: Long): String {
        val wake = sleepWakeAtMs
        if (wake == null || nowMs >= wake) return "awake"
        val minutes = (wake - nowMs) / 60_000
        return "sleeping (back in ~${minutes / 60}h ${minutes % 60}m)"
    }

    fun bondLabel(): String = when {
        bond >= 100 * BOND_SCALE -> "inseparable"
        bond >= 60 * BOND_SCALE -> "close"
        bond >= 30 * BOND_SCALE -> "comfortable"
        bond >= 10 * BOND_SCALE -> "getting to know each other"
        else -> "just met"
    }

    companion object {
        const val MAX_HUNGER = 20.0
        const val BOND_SCALE = 50
        const val HUNGRY_AT = 5.0   // hunger at or below this: he is hungry

        private val json = Json { ignoreUnknownKeys = true }

        /** Parses the `/api/load-save` response body: `{ "save": {...}, "saveCode": "..." }`. */
        fun parseResponse(body: String): LilguySnapshot {
            val root = json.parseToJsonElement(body).jsonObject
            val save = (root["save"] as? JsonObject) ?: error("Response has no save")
            return fromSave(save)
        }

        fun fromSave(save: JsonObject): LilguySnapshot = LilguySnapshot(
            mood = save.int("mood", 2).coerceIn(1, 3),
            hunger = save.double("hunger", MAX_HUNGER),
            lastHungerCheckMs = (save["last_hunger_check"] as? JsonPrimitive)?.contentOrNull()?.let(::parseInstantMs),
            bond = save.double("bond", 0.0),
            streak = save.int("streak", 0),
            unlockedTiers = parseTiers(save["unlocked_tiers"]),
            sleepWakeAtMs = save.double("sleep_wake_at", Double.NaN).takeIf { !it.isNaN() && it > 0 }?.toLong(),
            username = (save["username"] as? JsonPrimitive)?.contentOrNull()?.takeIf { it.isNotBlank() },
        )

        private fun JsonPrimitive.contentOrNull(): String? = if (isString) content else null

        private fun JsonObject.double(key: String, default: Double): Double =
            (this[key] as? JsonPrimitive)?.doubleOrNull ?: default

        private fun JsonObject.int(key: String, default: Int): Int = double(key, default.toDouble()).toInt()

        private fun parseInstantMs(text: String): Long? =
            runCatching { Instant.parse(text).toEpochMilli() }.getOrNull()

        /** Firebase returns arrays as JSON arrays, or as objects when entries are sparse. */
        private fun elements(el: JsonElement?): List<JsonElement> = when (el) {
            is JsonArray -> el.toList()
            is JsonObject -> el.values.toList()
            else -> emptyList()
        }

        private fun parseTiers(el: JsonElement?): Set<Int> =
            elements(el).mapNotNull { (it as? JsonPrimitive)?.doubleOrNull?.toInt() }.toSet()
    }
}

/** The lines he says, copied from lilguy's state-data.js so the TV sounds like the game. */
internal object LilguySpeech {
    private val happy = listOf(
        "hehe :)", "today's a good day", "glad you're here",
        "i love you <3", "i like it when you're around",
        "thank you for spending time with me",
    )
    private val neutral = listOf(
        "...", "just vibing", "hm", "wassup.",
        "today felt normal. in a good way",
        "do you ever wonder why theres so much violence",
        "i've been thinking about that walk earlier",
        "do you ever wonder what's outside the window",
        "sometimes i just sit here and think",
        "someday...ill see others like me",
    )
    private val angry = listOf(">:(", "not now.", ">:{", "leave me alone.", "its lonely when you leave me")
    private val season = mapOf(
        "winter" to listOf("it's cold out there, huh", "i wish i could see snow", "let's stay inside today"),
        "spring" to listOf("everything is growing again", "i can smell the flowers. probably.", "spring always feels hopeful"),
        "summer" to listOf("it's so warm out", "summer's my favorite honestly", "i bet its bright outside right now"),
        "fall" to listOf("the leaves must be falling", "fall always feels a little nostalgic", "cozy season, right?"),
    )

    /** Bond thresholds (bond points) that unlock extra lines for his happy moods. */
    private val tiers = listOf(
        Tier(10 * LilguySnapshot.BOND_SCALE, listOf("hehe, i feel closer to you now", "something feels different. good different.")),
        Tier(30 * LilguySnapshot.BOND_SCALE, listOf("i wanna dance!!", "watch this!")),
        Tier(60 * LilguySnapshot.BOND_SCALE, listOf("you're my favorite person, you know that?", "i really mean it. thank you.")),
        Tier(100 * LilguySnapshot.BOND_SCALE, listOf("we've really been through it together huh", "i wouldn't trade this for anything")),
    )

    private class Tier(val threshold: Int, val lines: List<String>)

    fun seasonOf(month: Int): String = when (month) {
        12, 1, 2 -> "winter"
        3, 4, 5 -> "spring"
        6, 7, 8 -> "summer"
        else -> "fall"
    }

    // Not in the game: written for the TV so his words match a low hunger bar.
    private val hungry = listOf(
        "my tummy is making noises", "i could really go for a snack", "so hungry...",
        "i'm getting kind of hungry", "is it dinner time yet?",
    )

    /**
     * Picks a line that fits how he feels right now ([LilguySnapshot.feelingAt]). Like tick.js,
     * happy and neutral moods mix in a seasonal line a quarter of the time.
     */
    fun pick(s: LilguySnapshot, month: Int, nowMs: Long, random: Random = Random()): String {
        val seasonal = random.nextInt(4) == 0
        return when (s.feelingAt(nowMs)) {
            Feeling.HUNGRY -> hungry.random(random)
            Feeling.ANGRY -> angry.random(random)
            Feeling.NEUTRAL -> if (seasonal) season.getValue(seasonOf(month)).random(random) else neutral.random(random)
            Feeling.HAPPY ->
                if (seasonal) season.getValue(seasonOf(month)).random(random)
                else (happy + unlockedLines(s)).random(random)
        }
    }

    private fun unlockedLines(s: LilguySnapshot): List<String> =
        tiers.filter { it.threshold in s.unlockedTiers }.flatMap { it.lines }

    private fun <T> List<T>.random(r: Random): T = this[r.nextInt(size)]
}

/**
 * Decides which face he shows. Calculated here instead of read from the game, which is cheaper.
 *
 * Time is cut into 5-minute slots. In each slot:
 *  - his resting face is `<_` (weight 3) or `_>` (weight 2), so these two are the common ones;
 *  - exactly one of the four rarer faces (`o7`, `o/`, `^_^`, `O_O`) flashes for 30 seconds at a
 *    random moment, picked evenly. 40 minutes is 8 slots, so that is 8 flashes shared by four
 *    faces: each rare face about twice every 40 minutes.
 * When he is distressed (see [LilguySnapshot.isDistressed]) the resting face becomes `>_<` and
 * the cheerful flashes are skipped, so his picture never contradicts his hunger and mood.
 */
internal class FaceScheduler(private val random: Random = Random()) {
    companion object {
        const val SLOT_MS = 5 * 60_000L
        const val FLASH_MS = 30_000L
        const val DISTRESSED = ">_<"

        /** Resting faces and their weights. */
        val COMMON: List<Pair<String, Int>> = listOf("<_" to 3, "_>" to 2)
        val RARE: List<String> = listOf("o7", "o/", "^_^", "O_O")
        private val CHEERFUL = setOf("o7", "o/", "^_^")
    }

    private var slot = Long.MIN_VALUE
    private var resting = COMMON.first().first
    private var flashFace = RARE.first()
    private var flashStartMs = 0L

    fun faceAt(nowMs: Long, distressed: Boolean): String {
        val current = Math.floorDiv(nowMs, SLOT_MS)
        if (current != slot) roll(current)
        val flashing = nowMs >= flashStartMs && nowMs < flashStartMs + FLASH_MS
        return if (distressed) {
            if (flashing && flashFace !in CHEERFUL) flashFace else DISTRESSED
        } else {
            if (flashing) flashFace else resting
        }
    }

    private fun roll(newSlot: Long) {
        slot = newSlot
        var pick = random.nextInt(COMMON.sumOf { it.second })
        resting = COMMON.first { pick -= it.second; pick < 0 }.first
        flashFace = RARE[random.nextInt(RARE.size)]
        flashStartMs = newSlot * SLOT_MS + random.nextInt((SLOT_MS - FLASH_MS).toInt())
    }
}
