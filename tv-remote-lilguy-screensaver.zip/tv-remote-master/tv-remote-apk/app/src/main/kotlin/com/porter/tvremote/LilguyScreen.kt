package com.porter.tvremote

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.service.dreams.DreamService
import android.text.format.DateFormat
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** Everything the screen shows, swapped in whole so drawing never sees a half-update. */
internal data class ScreenData(
    val lilguy: LilguySnapshot? = null,
    val lilguyError: String? = null,
    val weather: Weather? = null,
    val track: Track? = null,
    val line: String = "...",
)

/** Remembers the previous value of something so a change can cross-fade instead of snapping. */
private class Fade<T>(initial: T) {
    var current: T = initial
    var previous: T = initial
    private var changedAt = 0L

    fun set(value: T, nowMs: Long) {
        if (value != current) {
            previous = current
            current = value
            changedAt = nowMs
        }
    }

    /** 0 right after a change, 1 once the fade has finished. */
    fun progress(nowMs: Long, durationMs: Long): Float =
        if (changedAt == 0L) 1f else ((nowMs - changedAt) / durationMs.toFloat()).coerceIn(0f, 1f)
}

/**
 * Draws the screensaver. Two looks:
 *  - lilguy awake (or no save code set up): clock, weather, music, and his stats and speech
 *  - lilguy asleep: pure black with only the track, artist, date, time and weather
 *
 * Smoothness: while awake it redraws about 30 times a second. Bars glide to new values, the
 * face, his words and the track fade between each other, and the anti-burn-in drift is a slow
 * continuous wave instead of a jump once a minute. While asleep it redraws once a second.
 */
internal class LilguyScreenView(context: Context) : View(context) {
    @Volatile var data: ScreenData = ScreenData()
        set(value) { field = value; postInvalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mono = Typeface.MONOSPACE
    private val sans = Typeface.SANS_SERIF
    private val italic = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
    private val bar = RectF()

    private val is24 = DateFormat.is24HourFormat(context)
    private val timeFormat = SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault())
    private val ampmFormat = SimpleDateFormat("a", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())

    private val faces = FaceScheduler()
    private val faceFade = Fade("")
    private val lineFade = Fade("")
    private val trackFade = Fade<Track?>(null)

    // What the bars currently show; they ease toward the real value. Negative = not yet set.
    private var shownHunger = -1f
    private var shownHp = -1f
    private var lastFrameAt = 0L

    private var animating = false
    private val nextFrame = Runnable { invalidate() }

    init { setBackgroundColor(Color.BLACK) }

    /** The controller turns the frame loop on while the screen is up and off when it is not. */
    fun setAnimating(on: Boolean) {
        animating = on
        removeCallbacks(nextFrame)
        if (on) postInvalidate()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(nextFrame)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val now = System.currentTimeMillis()
        val d = data
        val sleeping = d.lilguy?.isSleeping(now) == true
        val u = height / 1080f

        // Slow continuous drift so nothing sits on the same pixels for hours (TV burn-in).
        val minutes = now / 60_000.0
        val dx = (sin(minutes * 2 * PI / 23) * 20 * u).toFloat()
        val dy = (sin(minutes * 2 * PI / 31) * 12 * u).toFloat()
        canvas.save()
        canvas.translate(dx, dy)
        if (sleeping) drawSleeping(canvas, d, u, now) else drawAwake(canvas, d, u, now)
        canvas.restore()

        lastFrameAt = now
        removeCallbacks(nextFrame)
        if (animating) postDelayed(nextFrame, if (sleeping) 1_000L else FRAME_MS)
    }

    // ── Sleeping: black, grey text, nothing else ─────────────────────────────

    private fun drawSleeping(c: Canvas, d: ScreenData, u: Float, now: Long) {
        val cx = width / 2f
        var y = height * 0.36f
        val date = Date(now)
        paint.color = GREY_BRIGHT
        text(c, time(date), cx, y, 230 * u, sans, Paint.Align.CENTER)
        y += 90 * u
        paint.color = GREY
        text(c, dateFormat.format(date), cx, y, 52 * u, sans, Paint.Align.CENTER)
        y += 76 * u
        d.weather?.let { text(c, it.display(), cx, y, 46 * u, sans, Paint.Align.CENTER); y += 100 * u }
        trackFade.set(d.track, now)
        drawTrackFaded(c, now, cx, y, u, Paint.Align.CENTER)
    }

    // ── Awake ────────────────────────────────────────────────────────────────

    private fun drawAwake(c: Canvas, d: ScreenData, u: Float, now: Long) {
        val left = 90 * u
        val date = Date(now)
        var y = 230 * u
        paint.color = Color.WHITE
        text(c, time(date), left, y, 170 * u, sans, Paint.Align.LEFT)
        y += 70 * u
        paint.color = GREY_BRIGHT
        text(c, dateFormat.format(date), left, y, 46 * u, sans, Paint.Align.LEFT)
        y += 64 * u
        paint.color = GREY
        d.weather?.let { text(c, it.display(), left, y, 42 * u, sans, Paint.Align.LEFT) }
        trackFade.set(d.track, now)
        drawTrackFaded(c, now, left, height - 110 * u, u, Paint.Align.LEFT)

        // Credit, bottom right, in lilguy's orange.
        paint.color = ORANGE
        text(c, "made with Claude and lilguydev", width - 60 * u, height - 50 * u, 26 * u, sans, Paint.Align.RIGHT)

        val l = d.lilguy
        val col = width * 0.60f
        if (l == null) {
            paint.color = GREY
            val msg = d.lilguyError ?: "Add a lilguy save code in the web remote to see him here"
            text(c, msg, col, height * 0.45f, 34 * u, sans, Paint.Align.LEFT)
            return
        }

        val dt = ((now - lastFrameAt) / 1000f).coerceIn(0f, 0.25f)
        val cx = col + 170 * u

        // Face and words both come from how he feels right now, so they agree with the bars.
        faceFade.set(faces.faceAt(now, l.isDistressed(now)), now)
        lineFade.set(d.line, now)
        val facePeriod = faceFade.progress(now, FACE_FADE_MS)
        drawFace(c, faceFade.previous, cx, 250 * u, u, 1f - facePeriod)
        drawFace(c, faceFade.current, cx, 250 * u, u, facePeriod)

        val linePeriod = lineFade.progress(now, LINE_FADE_MS)
        drawSpeech(c, lineFade.previous, cx, 330 * u, u, 1f - linePeriod)
        drawSpeech(c, lineFade.current, cx, 330 * u, u, linePeriod)

        val hunger = l.hungerAt(now)
        shownHunger = ease(shownHunger, (hunger / LilguySnapshot.MAX_HUNGER).toFloat(), dt)
        shownHp = ease(shownHp, l.hp.toFloat() / l.maxHp, dt)

        var row = 520 * u
        row = statBar(c, "HUNGER", shownHunger, "%.0f / 20".format(hunger), col, row, u,
            if (hunger <= LilguySnapshot.HUNGRY_AT) Color.rgb(255, 90, 90) else Color.rgb(120, 220, 120))
        row = statBar(c, "HP", shownHp, "${l.hp} / ${l.maxHp}", col, row, u, Color.rgb(255, 120, 150))

        paint.color = GREY_BRIGHT
        text(c, "LV ${l.level}   DMG ${l.dmg}   ${l.bondLabel()}", col, row + 6 * u, 34 * u, sans, Paint.Align.LEFT)
        row += 52 * u
        text(c, "SLEEP  awake", col, row, 34 * u, sans, Paint.Align.LEFT)
        row += 64 * u

        for (slot in listOf("weapon", "armor", "item")) {
            val g = l.gearIn(slot)
            paint.color = if (g == null) GREY_DIM else rarityColor(g.rarity)
            val label = if (g == null) "—" else "${g.rarity} +${g.bonus}"
            text(c, slot.uppercase().padEnd(7) + label, col, row, 32 * u, mono, Paint.Align.LEFT)
            row += 46 * u
        }
    }

    private fun drawFace(c: Canvas, face: String, cx: Float, y: Float, u: Float, alpha: Float) {
        if (face.isEmpty() || alpha <= 0f) return
        paint.color = if (face == FaceScheduler.DISTRESSED) Color.rgb(255, 120, 90) else Color.rgb(0, 255, 120)
        text(c, face, cx, y, 150 * u, mono, Paint.Align.CENTER, alpha)
    }

    private fun drawSpeech(c: Canvas, line: String, cx: Float, y: Float, u: Float, alpha: Float) {
        if (line.isEmpty() || alpha <= 0f) return
        paint.color = Color.rgb(255, 235, 210)
        var sy = y
        for (part in wrap("\"$line\"", 30)) {
            text(c, part, cx, sy, 40 * u, italic, Paint.Align.CENTER, alpha)
            sy += 52 * u
        }
    }

    private fun statBar(c: Canvas, label: String, frac: Float, value: String, x: Float, y: Float, u: Float, color: Int): Float {
        paint.color = GREY
        text(c, label, x, y, 26 * u, sans, Paint.Align.LEFT)
        val top = y + 14 * u
        val w = width * 0.30f
        paint.color = Color.argb(60, 255, 255, 255)
        bar.set(x, top, x + w, top + 26 * u)
        c.drawRoundRect(bar, 13 * u, 13 * u, paint)
        paint.color = color
        bar.set(x, top, x + w * frac.coerceIn(0f, 1f), top + 26 * u)
        c.drawRoundRect(bar, 13 * u, 13 * u, paint)
        paint.color = GREY_BRIGHT
        text(c, value, x + w + 24 * u, top + 24 * u, 28 * u, sans, Paint.Align.LEFT)
        return top + 80 * u
    }

    private fun drawTrackFaded(c: Canvas, now: Long, x: Float, y: Float, u: Float, align: Paint.Align) {
        val p = trackFade.progress(now, FACE_FADE_MS)
        trackFade.previous?.let { drawTrack(c, it, x, y, u, align, 1f - p) }
        trackFade.current?.let { drawTrack(c, it, x, y, u, align, p) }
    }

    private fun drawTrack(c: Canvas, t: Track, x: Float, y: Float, u: Float, align: Paint.Align, alpha: Float) {
        if (alpha <= 0f) return
        paint.color = GREY_BRIGHT
        text(c, "♪  " + ellipsize(t.title, 46), x, y, 46 * u, sans, align, alpha)
        if (t.artist.isNotBlank()) {
            paint.color = GREY
            text(c, ellipsize(t.artist, 56), x, y + 56 * u, 36 * u, sans, align, alpha)
        }
    }

    private fun rarityColor(rarity: String): Int = when (rarity) {
        "uncommon" -> Color.rgb(110, 220, 110)
        "rare" -> Color.rgb(100, 160, 255)
        "epic" -> Color.rgb(190, 110, 255)
        "legendary" -> Color.rgb(255, 180, 50)
        else -> GREY_BRIGHT
    }

    /** Moves [shown] a fraction of the way to [target]; the same speed whatever the frame rate. */
    private fun ease(shown: Float, target: Float, dt: Float): Float =
        if (shown < 0f) target else shown + (target - shown) * (1f - exp(-dt * 4f))

    private fun time(d: Date): String =
        if (is24) timeFormat.format(d) else timeFormat.format(d) + " " + ampmFormat.format(d).lowercase()

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, face: Typeface, align: Paint.Align, alpha: Float = 1f) {
        paint.textSize = size
        paint.typeface = face
        paint.textAlign = align
        val baseAlpha = paint.alpha
        paint.alpha = (baseAlpha * alpha.coerceIn(0f, 1f)).toInt()
        c.drawText(s, x, y, paint)
        paint.alpha = baseAlpha // a fade must not leak into the next thing drawn
    }

    private fun ellipsize(s: String, max: Int) = if (s.length <= max) s else s.take(max - 1) + "…"

    private fun wrap(s: String, maxChars: Int): List<String> {
        val lines = mutableListOf<String>()
        var cur = ""
        for (word in s.split(' ')) {
            if (cur.isNotEmpty() && cur.length + 1 + word.length > maxChars) { lines += cur; cur = word }
            else cur = if (cur.isEmpty()) word else "$cur $word"
        }
        if (cur.isNotEmpty()) lines += cur
        return lines
    }

    private companion object {
        const val FRAME_MS = 33L          // ~30 frames per second while awake
        const val FACE_FADE_MS = 400L
        const val LINE_FADE_MS = 600L
        val GREY_BRIGHT = Color.rgb(200, 200, 205)
        val GREY = Color.rgb(130, 130, 138)
        val GREY_DIM = Color.rgb(70, 70, 76)
        val ORANGE = Color.rgb(255, 127, 0)
    }
}

/** Feeds a [LilguyScreenView]: refreshes save, weather and music, and times his lines. */
internal class LilguyScreenController(private val context: Context, private val view: LilguyScreenView) {
    private var scope: CoroutineScope? = null
    private var lastLineAt = 0L

    fun start() {
        stop()
        lastLineAt = 0L
        val s = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        scope = s
        // Weather every 15 minutes, save every minute, music every 3 seconds. Failures keep
        // the previous value on screen; only the first failure of the save shows a message.
        s.launch { while (isActive) { refreshWeather(); delay(15 * 60_000L) } }
        s.launch { while (isActive) { refreshLilguy(); delay(60_000L) } }
        s.launch { while (isActive) { refreshTrack(); delay(3_000L) } }
        // While the screen is up the TV is in use, so the server's 24 h idle timer keeps resetting.
        s.launch { while (isActive) { IdleTimer.shared.touch(); delay(1_000L) } }
        s.launch { while (isActive) { maybeChangeLine(); delay(5_000L) } }
        view.setAnimating(true)
    }

    fun stop() {
        view.setAnimating(false)
        scope?.cancel()
        scope = null
    }

    private suspend fun refreshWeather() {
        runCatching { withContext(Dispatchers.IO) { WeatherApi.fetch(context) } }
            .onSuccess { view.data = view.data.copy(weather = it) }
            .onFailure { Log.w(TAG, "Weather failed: ${it.message}") }
    }

    private suspend fun refreshLilguy() {
        val code = LilguySettings.saveCode(context)
        if (code == null) { view.data = view.data.copy(lilguy = null, lilguyError = null); return }
        runCatching { withContext(Dispatchers.IO) { LilguyApi.fetch(code) } }
            .onSuccess { view.data = view.data.copy(lilguy = it, lilguyError = null) }
            .onFailure {
                Log.w(TAG, "Lilguy failed: ${it.message}")
                if (view.data.lilguy == null) view.data = view.data.copy(lilguyError = it.message)
            }
    }

    private suspend fun refreshTrack() {
        val track = withContext(Dispatchers.IO) { NowPlaying.current(context) }
        if (track != view.data.track) view.data = view.data.copy(track = track)
    }

    /**
     * His line changes once every [LINE_INTERVAL_MS] and no sooner (the game itself is meant to
     * do this, but until that is fixed there, the wait is enforced here). The first line appears
     * as soon as his save has loaded.
     */
    private fun maybeChangeLine() {
        val l = view.data.lilguy ?: return
        val now = System.currentTimeMillis()
        if (lastLineAt != 0L && now - lastLineAt < LINE_INTERVAL_MS) return
        lastLineAt = now
        view.data = view.data.copy(line = LilguySpeech.pick(l, Calendar.getInstance().get(Calendar.MONTH) + 1, now))
    }

    private companion object {
        const val TAG = "LilguyScreen"
        const val LINE_INTERVAL_MS = 3 * 60_000L
    }
}

/** The real Android screensaver ("Daydream"): pick it in Settings → Device Preferences → Screen saver. */
class LilguyDreamService : DreamService() {
    private var controller: LilguyScreenController? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = false
        isFullscreen = true
        val view = LilguyScreenView(this)
        setContentView(view)
        controller = LilguyScreenController(this, view)
    }

    override fun onDreamingStarted() {
        super.onDreamingStarted()
        controller?.start()
    }

    override fun onDreamingStopped() {
        controller?.stop()
        super.onDreamingStopped()
    }

    override fun onDetachedFromWindow() {
        controller?.stop()
        controller = null
        super.onDetachedFromWindow()
    }
}

/**
 * The same screen as a normal activity. This is what the "screensaver" macro step starts, because
 * a macro can launch an activity on demand but cannot start a dream. Any key press leaves it
 * (volume keys excepted), which is also how a following macro step like "home" gets out.
 */
class LilguyScreenActivity : Activity() {
    private var controller: LilguyScreenController? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val view = LilguyScreenView(this)
        view.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        setContentView(view)
        controller = LilguyScreenController(this, view)
    }

    override fun onStart() { super.onStart(); controller?.start() }
    override fun onStop() { controller?.stop(); super.onStop() }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE) return super.onKeyDown(keyCode, event)
        finish()
        return true
    }
}
