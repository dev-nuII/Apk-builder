package com.porter.tvremote

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.service.dreams.DreamService
import android.text.format.DateFormat
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Everything the screen shows, swapped in whole so drawing never sees a half-update. */
internal data class ScreenData(
    val lilguy: LilguySnapshot? = null,
    val lilguyError: String? = null,
    val weather: Weather? = null,
    val track: Track? = null,
    val line: String = "...",
)

/**
 * Draws the screensaver. Two looks:
 *  - lilguy awake (or no save code set up): clock, weather, music, and his stats and speech
 *  - lilguy asleep: pure black with only the track, artist, date, time and weather
 */
internal class LilguyScreenView(context: Context) : View(context) {
    @Volatile var data: ScreenData = ScreenData()
        set(value) { field = value; postInvalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mono = Typeface.MONOSPACE
    private val sans = Typeface.SANS_SERIF
    private val bar = RectF()

    private val is24 = DateFormat.is24HourFormat(context)
    private val timeFormat = SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault())
    private val ampmFormat = SimpleDateFormat("a", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())

    init { setBackgroundColor(Color.BLACK) }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val d = data
        val now = System.currentTimeMillis()
        val sleeping = d.lilguy?.isSleeping(now) == true
        // Slow drift so nothing sits on the same pixels for hours (TV burn-in).
        val minute = Calendar.getInstance().get(Calendar.MINUTE)
        val u = height / 1080f
        val dx = ((minute % 10) - 5) * 6f * u
        val dy = (((minute / 10) % 6) - 3) * 6f * u
        canvas.save()
        canvas.translate(dx, dy)
        if (sleeping) drawSleeping(canvas, d, u) else drawAwake(canvas, d, u, now)
        canvas.restore()
    }

    // ── Sleeping: black, grey text, nothing else ─────────────────────────────

    private fun drawSleeping(c: Canvas, d: ScreenData, u: Float) {
        val cx = width / 2f
        var y = height * 0.36f
        val date = Date()
        paint.color = GREY_BRIGHT
        text(c, time(date), cx, y, 230 * u, sans, Paint.Align.CENTER)
        y += 90 * u
        paint.color = GREY
        text(c, dateFormat.format(date), cx, y, 52 * u, sans, Paint.Align.CENTER)
        y += 76 * u
        d.weather?.let { text(c, it.display(), cx, y, 46 * u, sans, Paint.Align.CENTER); y += 100 * u }
        d.track?.let { drawTrack(c, it, cx, y, u, Paint.Align.CENTER) }
    }

    // ── Awake ────────────────────────────────────────────────────────────────

    private fun drawAwake(c: Canvas, d: ScreenData, u: Float, nowMs: Long) {
        val left = 90 * u
        val date = Date(nowMs)
        var y = 230 * u
        paint.color = Color.WHITE
        text(c, time(date), left, y, 170 * u, sans, Paint.Align.LEFT)
        y += 70 * u
        paint.color = GREY_BRIGHT
        text(c, dateFormat.format(date), left, y, 46 * u, sans, Paint.Align.LEFT)
        y += 64 * u
        paint.color = GREY
        d.weather?.let { text(c, it.display(), left, y, 42 * u, sans, Paint.Align.LEFT) }
        d.track?.let { drawTrack(c, it, left, height - 110 * u, u, Paint.Align.LEFT) }

        val l = d.lilguy
        val col = width * 0.60f
        if (l == null) {
            paint.color = GREY
            val msg = d.lilguyError ?: "Add a lilguy save code in the web remote to see him here"
            text(c, msg, col, height * 0.45f, 34 * u, sans, Paint.Align.LEFT)
            return
        }

        paint.color = Color.rgb(0, 255, 120)
        text(c, LilguySpeech.face(l), col + 170 * u, 250 * u, 150 * u, mono, Paint.Align.CENTER)
        paint.color = Color.rgb(255, 235, 210)
        var sy = 330 * u
        for (line in wrap("\"${d.line}\"", 30, 40 * u)) {
            text(c, line, col + 170 * u, sy, 40 * u, Typeface.create(sans, Typeface.ITALIC), Paint.Align.CENTER)
            sy += 52 * u
        }

        var row = 520 * u
        val hunger = l.hungerAt(nowMs)
        row = statBar(c, "HUNGER", hunger / LilguySnapshot.MAX_HUNGER, "%.0f / 20".format(hunger), col, row, u,
            if (hunger < 6) Color.rgb(255, 90, 90) else Color.rgb(120, 220, 120))
        row = statBar(c, "HP", l.hp.toFloat() / l.maxHp, "${l.hp} / ${l.maxHp}", col, row, u, Color.rgb(255, 120, 150))

        paint.color = GREY_BRIGHT
        text(c, "LV ${l.level}   DMG ${l.dmg}   ${l.bondLabel()}", col, row + 6 * u, 34 * u, sans, Paint.Align.LEFT)
        row += 52 * u
        text(c, "SLEEP  awake", col, row, 34 * u, sans, Paint.Align.LEFT)
        row += 64 * u

        for (slot in listOf("weapon", "armor", "item")) {
            val g = l.gearIn(slot)
            paint.color = if (g == null) GREY_DIM else rarityColor(g.rarity)
            val label = if (g == null) "—" else "${g.rarity} +${g.bonus}"
            text(c, slot.uppercase().padEnd(7) + label, col, row, 32 * u, mono, Paint.Align.LEFT)
            row += 46 * u
        }
    }

    private fun statBar(c: Canvas, label: String, frac: Float, value: String, x: Float, y: Float, u: Float, color: Int): Float {
        paint.color = GREY
        text(c, label, x, y, 26 * u, sans, Paint.Align.LEFT)
        val top = y + 14 * u
        val w = width * 0.30f
        paint.color = Color.argb(60, 255, 255, 255)
        bar.set(x, top, x + w, top + 26 * u)
        c.drawRoundRect(bar, 13 * u, 13 * u, paint)
        paint.color = color
        bar.set(x, top, x + w * frac.coerceIn(0f, 1f), top + 26 * u)
        c.drawRoundRect(bar, 13 * u, 13 * u, paint)
        paint.color = GREY_BRIGHT
        text(c, value, x + w + 24 * u, top + 24 * u, 28 * u, sans, Paint.Align.LEFT)
        return top + 80 * u
    }

    private fun drawTrack(c: Canvas, t: Track, x: Float, y: Float, u: Float, align: Paint.Align) {
        paint.color = GREY_BRIGHT
        text(c, "♪  " + ellipsize(t.title, 46), x, y, 46 * u, sans, align)
        if (t.artist.isNotBlank()) {
            paint.color = GREY
            text(c, ellipsize(t.artist, 56), x, y + 56 * u, 36 * u, sans, align)
        }
    }

    private fun rarityColor(rarity: String): Int = when (rarity) {
        "uncommon" -> Color.rgb(110, 220, 110)
        "rare" -> Color.rgb(100, 160, 255)
        "epic" -> Color.rgb(190, 110, 255)
        "legendary" -> Color.rgb(255, 180, 50)
        else -> GREY_BRIGHT
    }

    private fun time(d: Date): String =
        if (is24) timeFormat.format(d) else timeFormat.format(d) + " " + ampmFormat.format(d).lowercase()

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, face: Typeface, align: Paint.Align) {
        paint.textSize = size
        paint.typeface = face
        paint.textAlign = align
        c.drawText(s, x, y, paint)
    }

    private fun ellipsize(s: String, max: Int) = if (s.length <= max) s else s.take(max - 1) + "…"

    private fun wrap(s: String, maxChars: Int, @Suppress("UNUSED_PARAMETER") size: Float): List<String> {
        val lines = mutableListOf<String>()
        var cur = ""
        for (word in s.split(' ')) {
            if (cur.isNotEmpty() && cur.length + 1 + word.length > maxChars) { lines += cur; cur = word }
            else cur = if (cur.isEmpty()) word else "$cur $word"
        }
        if (cur.isNotEmpty()) lines += cur
        return lines
    }

    private companion object {
        val GREY_BRIGHT = Color.rgb(200, 200, 205)
        val GREY = Color.rgb(130, 130, 138)
        val GREY_DIM = Color.rgb(70, 70, 76)
    }
}

/** Feeds a [LilguyScreenView]: redraws every second and refreshes save, weather and music. */
internal class LilguyScreenController(private val context: Context, private val view: LilguyScreenView) {
    private var scope: CoroutineScope? = null

    fun start() {
        stop()
        val s = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        scope = s
        // Weather every 15 minutes, save every minute, music every 3 seconds. Failures keep
        // the previous value on screen; only the first failure of the save shows a message.
        s.launch { while (isActive) { refreshWeather(); delay(15 * 60_000L) } }
        s.launch { while (isActive) { refreshLilguy(); delay(60_000L) } }
        s.launch { while (isActive) { refreshTrack(); delay(3_000L) } }
        // While the screen is up the TV is in use, so the server's 24 h idle timer keeps resetting.
        s.launch { while (isActive) { IdleTimer.shared.touch(); view.postInvalidate(); delay(1_000L) } }
        s.launch { while (isActive) { rotateLine(); delay(20_000L) } }
    }

    fun stop() {
        scope?.cancel()
        scope = null
    }

    private suspend fun refreshWeather() {
        runCatching { withContext(Dispatchers.IO) { WeatherApi.fetch(context) } }
            .onSuccess { view.data = view.data.copy(weather = it) }
            .onFailure { Log.w(TAG, "Weather failed: ${it.message}") }
    }

    private suspend fun refreshLilguy() {
        val code = LilguySettings.saveCode(context)
        if (code == null) { view.data = view.data.copy(lilguy = null, lilguyError = null); return }
        runCatching { withContext(Dispatchers.IO) { LilguyApi.fetch(code) } }
            .onSuccess {
                val firstLoad = view.data.lilguy == null
                view.data = view.data.copy(
                    lilguy = it,
                    lilguyError = null,
                    line = if (firstLoad) LilguySpeech.pick(it, Calendar.getInstance().get(Calendar.MONTH) + 1) else view.data.line,
                )
            }
            .onFailure {
                Log.w(TAG, "Lilguy failed: ${it.message}")
                if (view.data.lilguy == null) view.data = view.data.copy(lilguyError = it.message)
            }
    }

    private suspend fun refreshTrack() {
        val track = withContext(Dispatchers.IO) { NowPlaying.current(context) }
        if (track != view.data.track) view.data = view.data.copy(track = track)
    }

    private fun rotateLine() {
        val l = view.data.lilguy ?: return
        view.data = view.data.copy(line = LilguySpeech.pick(l, Calendar.getInstance().get(Calendar.MONTH) + 1))
    }

    private companion object { const val TAG = "LilguyScreen" }
}

/** The real Android screensaver ("Daydream"): pick it in Settings → Device Preferences → Screen saver. */
class LilguyDreamService : DreamService() {
    private var controller: LilguyScreenController? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = false
        isFullscreen = true
        val view = LilguyScreenView(this)
        setContentView(view)
        controller = LilguyScreenController(this, view)
    }

    override fun onDreamingStarted() {
        super.onDreamingStarted()
        controller?.start()
    }

    override fun onDreamingStopped() {
        controller?.stop()
        super.onDreamingStopped()
    }

    override fun onDetachedFromWindow() {
        controller?.stop()
        controller = null
        super.onDetachedFromWindow()
    }
}

/**
 * The same screen as a normal activity. This is what the "screensaver" macro step starts, because
 * a macro can launch an activity on demand but cannot start a dream. Any key press leaves it
 * (volume keys excepted), which is also how a following macro step like "home" gets out.
 */
class LilguyScreenActivity : Activity() {
    private var controller: LilguyScreenController? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val view = LilguyScreenView(this)
        view.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        setContentView(view)
        controller = LilguyScreenController(this, view)
    }

    override fun onStart() { super.onStart(); controller?.start() }
    override fun onStop() { controller?.stop(); super.onStop() }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE) return super.onKeyDown(keyCode, event)
        finish()
        return true
    }
}
