package com.porter.tvremote

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Turns the web remote's trackpad into a mouse on the TV.
 *
 * Android TV has no pointer of its own, so this service supplies the two halves of one:
 *  - a cursor: a small arrow in an accessibility overlay window that moves when [move] is called;
 *  - clicks: [click], [longPress] and [scroll] perform ordinary touch gestures at the cursor.
 *
 * It reads nothing from the screen (the config asks for no events), it only draws the arrow and
 * performs gestures. Android requires the user to enable it; [TrackpadSetup] does that over the
 * same loopback ADB link the rest of the app uses, so no trip through Settings is needed.
 *
 * Everything here runs on the main thread; the HTTP server calls in from its own threads.
 */
class TrackpadService : AccessibilityService() {
    private val main = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var cursorView: CursorView? = null
    private var layout: WindowManager.LayoutParams? = null

    private var screenWidth = 1920
    private var screenHeight = 1080
    private var cursorX = 960f
    private var cursorY = 540f

    private val hideCursor = Runnable { cursorView?.visibility = View.GONE }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        cursorX = screenWidth / 2f
        cursorY = screenHeight / 2f

        val size = (CURSOR_DP * metrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = cursorX.toInt()
            y = cursorY.toInt()
        }
        val view = CursorView(this).apply { visibility = View.GONE }
        wm.addView(view, params)
        layout = params
        cursorView = view
    }

    /** Moves the cursor by [dx], [dy] pixels (clamped to the screen) and shows it for a while. */
    fun move(dx: Float, dy: Float) {
        main.post {
            cursorX = (cursorX + dx.coerceIn(-MAX_STEP, MAX_STEP)).coerceIn(0f, screenWidth - 1f)
            cursorY = (cursorY + dy.coerceIn(-MAX_STEP, MAX_STEP)).coerceIn(0f, screenHeight - 1f)
            val params = layout ?: return@post
            params.x = cursorX.toInt()
            params.y = cursorY.toInt()
            runCatching { windowManager?.updateViewLayout(cursorView, params) }
            showCursor()
        }
    }

    /** A tap at the cursor. */
    fun click() = main.post {
        showCursor()
        perform(Path().apply { moveTo(cursorX, cursorY) }, TAP_MS)
    }

    /** A press-and-hold at the cursor (opens context menus, starts drags in some apps). */
    fun longPress() = main.post {
        showCursor()
        perform(Path().apply { moveTo(cursorX, cursorY) }, LONG_PRESS_MS)
    }

    /**
     * Scrolls like a finger on the screen: positive [dy] drags down (content follows the finger),
     * so the pad behaves like a phone's natural scrolling.
     */
    fun scroll(dy: Float) {
        main.post {
            val travel = dy.coerceIn(-MAX_SCROLL, MAX_SCROLL)
            if (travel == 0f) return@post
            showCursor()
            val endY = (cursorY + travel).coerceIn(0f, screenHeight - 1f)
            val path = Path().apply { moveTo(cursorX, cursorY); lineTo(cursorX, endY) }
            perform(path, SCROLL_MS)
        }
    }

    private fun perform(path: Path, durationMs: Long) {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun showCursor() {
        cursorView?.visibility = View.VISIBLE
        main.removeCallbacks(hideCursor)
        main.postDelayed(hideCursor, CURSOR_HIDE_MS)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        removeCursor()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeCursor()
        super.onDestroy()
    }

    private fun removeCursor() {
        if (instance === this) instance = null
        main.removeCallbacks(hideCursor)
        cursorView?.let { runCatching { windowManager?.removeView(it) } }
        cursorView = null
    }

    /** A white arrow with a black outline so it shows on any background. */
    private class CursorView(context: Context) : View(context) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 3f; strokeJoin = Paint.Join.ROUND
        }
        private val arrow = Path()

        override fun onDraw(canvas: Canvas) {
            val s = width.toFloat()
            arrow.reset()
            arrow.moveTo(2f, 2f)               // the tip is the click point
            arrow.lineTo(2f, s * 0.85f)
            arrow.lineTo(s * 0.22f, s * 0.66f)
            arrow.lineTo(s * 0.36f, s * 0.98f)
            arrow.lineTo(s * 0.50f, s * 0.92f)
            arrow.lineTo(s * 0.36f, s * 0.62f)
            arrow.lineTo(s * 0.64f, s * 0.60f)
            arrow.close()
            canvas.drawPath(arrow, fill)
            canvas.drawPath(arrow, outline)
        }
    }

    companion object {
        private const val CURSOR_DP = 36
        private const val MAX_STEP = 400f
        private const val MAX_SCROLL = 900f
        private const val TAP_MS = 50L
        private const val LONG_PRESS_MS = 700L
        private const val SCROLL_MS = 150L
        private const val CURSOR_HIDE_MS = 8_000L

        /** The connected service, or null when it has not been enabled (or was turned off). */
        @Volatile
        var instance: TrackpadService? = null
            private set
    }
}

/** Switching the trackpad service on without opening Settings. */
internal object TrackpadSetup {
    fun component(context: Context): String =
        "${context.packageName}/${TrackpadService::class.java.name}"

    /** The value for `enabled_accessibility_services` with [component] added (kept if already there). */
    internal fun withComponent(current: String?, component: String): String {
        val existing = current.orEmpty().trim().takeUnless { it == "null" }
            ?.split(':')?.filter { it.isNotBlank() }.orEmpty()
        return (if (component in existing) existing else existing + component).joinToString(":")
    }

    /**
     * Uses the app's ADB shell (which may write secure settings) to enable the service. Android then
     * binds it within a second or two.
     */
    fun enable(adb: AdbController, context: Context) {
        val component = component(context)
        val current = adb.shell("settings get secure enabled_accessibility_services")
        adb.shell("settings put secure enabled_accessibility_services ${withComponent(current, component)}")
        adb.shell("settings put secure accessibility_enabled 1")
    }
}
